#pragma once
#include "game.h"

inline uint32_t lit(uint32_t c, float L, int Br, int Bg, int Bb) {
  if (L > 1.8f) L = 1.8f;
  int r = (int)(((c >> 16) & 255) * L) + Br, g = (int)(((c >> 8) & 255) * L) + Bg, b = (int)((c & 255) * L) + Bb;
  return 0xFF000000u | ((uint32_t)(r > 255 ? 255 : r) << 16) | ((uint32_t)(g > 255 ? 255 : g) << 8) | (uint32_t)(b > 255 ? 255 : b);
}
inline float mixf(float a, float b, float t) { return a + (b - a) * t; }

inline void renderWorld(Game& g) {
  static float cxs[SW], rdx[SW], rdy[SW], fxm[SW]; static int skyU[SW];
  const float ca = std::cos(g.ang), sa = std::sin(g.ang);
  const Vec2 dir(ca, sa), rgt(sa, -ca), plane(sa * PLANE, -ca * PLANE);
  const bool driving = g.car >= 0;
  float camH = driving ? .40f : .5f + g.z;
  float bobY = driving ? std::sin((float)g.clock * 25.f) * g.carSpeed * .08f : std::sin(g.bob * 2.f) * 2.5f;
  float shk = g.shake * (hrand(g.frame, 1, 3) - .5f) * 14.f;
  float horizon = SH * .5f + g.pitch + g.kick + bobY + shk;
  int hz = (int)horizon;

  float dl = g.daylight, dusk = clampf(1.f - std::fabs(g.sunSin) * 3.2f, 0.f, 1.f) * .7f;
  float hr = mixf(mixf(12, 176, dl), 225, dusk), hg = mixf(mixf(14, 92, dl), 96, dusk), hb = mixf(mixf(26, 60, dl), 42, dusk);
  float zr = mixf(3, 84, dl), zg = mixf(4, 36, dl), zb = mixf(9, 38, dl);
  float fogR = hr * .9f, fogG = hg * .9f, fogB = hb * .9f;
  float dens = .055f + .035f * (1.f - dl), amb = g.ambient;
  float fl = g.flashlight ? (hrand((int)(g.clock * 18), 7, 11) < .04f ? .25f : 1.15f) : 0.f;
  const uint8_t* gr = g.w.ground.data(); const uint8_t* ind = g.w.indoor.data();

  for (int x = 0; x < SW; x++) {
    float c = 2.f * x / SW - 1.f; cxs[x] = c;
    rdx[x] = dir.x + plane.x * c; rdy[x] = dir.y + plane.y * c;
    fxm[x] = std::max(0.f, 1.f - c * c * 1.8f);
    skyU[x] = (int)((std::atan2(rdy[x], rdx[x]) / (2 * PI) + .5f) * SKW) & (SKW - 1);
  }
  bool night = dl < .25f;
  for (int y = 0; y < SH; y++) {
    uint32_t* row = &FB[y * SW]; float pRow = y + .5f - horizon;
    if (pRow > 0) {  // ---- floor ----
      float rd = camH * FOCAL / pRow, f = 1.f - std::exp(-dens * rd), inv = 1.f - f;
      int Br = (int)(fogR * f), Bg = (int)(fogG * f), Bb = (int)(fogB * f);
      float fx = g.pos.x + rd * (dir.x - plane.x), fy = g.pos.y + rd * (dir.y - plane.y);
      float sx = rd * 2.f * plane.x / SW, sy = rd * 2.f * plane.y / SW;
      float flR = fl * std::max(0.f, 1.f - rd / 18.f) * 1.2f;
      for (int x = 0; x < SW; x++, fx += sx, fy += sy) {
        int ci = (int)std::floor(fx), cj = (int)std::floor(fy); int gt = 1; bool in = false;
        if ((unsigned)ci < (unsigned)MW && (unsigned)cj < (unsigned)MH) { gt = gr[cj * MW + ci]; in = ind[cj * MW + ci] != 0; }
        const Tex& T = A.floor[gt];
        int tx = (int)((fx - std::floor(fx)) * 64) & 63, ty = (int)((fy - std::floor(fy)) * 64) & 63;
        row[x] = lit(T.px[ty * 64 + tx], (amb * (in ? .7f : 1.f) + flR * fxm[x]) * inv, Br, Bg, Bb);
      }
    } else {  // ---- ceiling / sky ----
      float pc = horizon - (y + .5f); if (pc < .01f) pc = .01f;
      float cd = (1.f - camH) * FOCAL / pc, f = 1.f - std::exp(-dens * cd), inv = 1.f - f;
      int Br = (int)(fogR * f), Bg = (int)(fogG * f), Bb = (int)(fogB * f);
      float fx = g.pos.x + cd * (dir.x - plane.x), fy = g.pos.y + cd * (dir.y - plane.y);
      float sx = cd * 2.f * plane.x / SW, sy = cd * 2.f * plane.y / SW;
      float v = clampf(pc / (SH * .62f), 0.f, 1.f); int vi = (int)(v * (SKH - 1)); float vp = std::pow(v, .6f), cm = std::sqrt(v);
      float rr = mixf(hr, zr, vp), rg = mixf(hg, zg, vp), rb = mixf(hb, zb, vp);
      float flC = fl * std::max(0.f, 1.f - cd / 12.f);
      for (int x = 0; x < SW; x++, fx += sx, fy += sy) {
        int ci = (int)std::floor(fx), cj = (int)std::floor(fy);
        if ((unsigned)ci < (unsigned)MW && (unsigned)cj < (unsigned)MH && ind[cj * MW + ci]) {
          int tx = (int)((fx - std::floor(fx)) * 64) & 63, ty = (int)((fy - std::floor(fy)) * 64) & 63;
          row[x] = lit(A.ceil.px[ty * 64 + tx], (amb * .55f + flC * fxm[x]) * inv, Br, Bg, Bb);
        } else {
          float cl = A.sky[vi * SKW + skyU[x]] / 255.f, k = mixf(1.f, .5f + .95f * cl, cm);
          int r = (int)(rr * k), gg = (int)(rg * k), b = (int)(rb * k);
          if (night && hrand(skyU[x], vi * 3, 77) < .004f) { r += 150; gg += 150; b += 160; }
          row[x] = rgb(r, gg, b);
        }
      }
    }
  }
  // ---- sun & moon ----
  if (!g.w.indoor[(int)g.pos.y * MW + (int)g.pos.x]) {
    auto disc = [&](float az, float elev, int cr, int cg, int cb, float rad) {
      float d = az - g.ang; while (d > PI) d -= 2 * PI; while (d < -PI) d += 2 * PI;
      if (std::fabs(d) > 1.1f || elev < 0.f) return;
      float sx = SW * .5f - std::tan(d) * FOCAL, sy = horizon - std::tan(elev) * FOCAL;
      for (int dy = (int)-rad * 3; dy <= (int)rad * 3; dy++) for (int dx = (int)-rad * 3; dx <= (int)rad * 3; dx++) {
        float dd = std::sqrt((float)(dx * dx + dy * dy)) / rad; float a = dd < 1.f ? .95f : .5f * std::exp(-(dd - 1.f) * 1.6f);
        if (dy + sy < horizon) blendPx((int)sx + dx, (int)sy + dy, rgb(cr, cg, cb), a * .85f);
      }
    };
    float elev = std::asin(clampf(g.sunSin, -1.f, 1.f));
    disc(2.2f, elev, 255, 170, 90, 12.f); disc(2.2f + PI, -elev, 190, 200, 225, 8.f);
  }
  // ---- walls ----
  for (int x = 0; x < SW; x++) {
    RayHit h = castRay(g.w, g.pos, Vec2(rdx[x], rdy[x]), 64.f);
    if (!h.hit) { ZB[x] = 1e9f; continue; }
    float perp = h.dist; ZB[x] = perp;
    float lh = FOCAL / perp, top = horizon - lh * (1.f - camH), bot = horizon + lh * camH;
    int y0 = std::max(0, (int)top), y1 = std::min(SH - 1, (int)bot);
    float f = 1.f - std::exp(-dens * perp), inv = 1.f - f;
    int Br = (int)(fogR * f), Bg = (int)(fogG * f), Bb = (int)(fogB * f);
    float L = (amb * (h.side ? .72f : 1.f) + fl * fxm[x] * std::max(0.f, 1.f - perp / 18.f)) * inv;
    const Tex& T = A.wall[h.cv]; int tx = (int)(h.wx * 64) & 63;
    float step = 64.f / lh, tp = (y0 - top) * step;
    for (int y = y0; y <= y1; y++, tp += step) FB[y * SW + x] = lit(T.px[(((int)tp) & 63) * 64 + tx], L, Br, Bg, Bb);
  }
  // ---- sprites ----
  struct SV { int i; float d; };
  static std::vector<SV> vis; vis.clear();
  for (int i = 0; i < (int)g.w.ents.size(); i++) {
    const Ent& e = g.w.ents[i]; if (e.dead || i == g.car) continue;
    Vec2 rel = e.pos - g.pos; float depth = dot(rel, dir); bool beacon = e.k == K_RADIO || e.k == K_SHIP;
    if (depth < .2f || depth > (beacon ? 320.f : 40.f)) continue;
    if (std::fabs(dot(rel, rgt)) > depth * 1.2f + e.scale * 5.f) continue;
    vis.push_back({i, depth});
  }
  std::sort(vis.begin(), vis.end(), [](const SV& a, const SV& b) { return a.d > b.d; });
  for (const SV& v : vis) {
    const Ent& e = g.w.ents[v.i]; float depth = v.d; bool beacon = e.k == K_RADIO || e.k == K_SHIP;
    int ti = e.tex; bool flip = false;
    if (e.k == K_RADIO) ti = ((int)(g.clock * 1.5) & 1) ? S_RADIO_ON : S_RADIO_OFF;
    else if (e.k == K_LAMP) ti = hrand((int)(e.t * 8), v.i, 5) < .08f ? S_LAMP_OFF : S_LAMP_ON;
    else if (isEnemy(e.k) || e.k == K_PHANTOM) flip = ((int)(e.t * 2.5f)) & 1;
    const Tex& T = A.spr[ti];
    float lat = dot(e.pos - g.pos, rgt), H = FOCAL * e.scale / depth, Wd = H * T.w / T.h, sx = SW * .5f + FOCAL * lat / depth;
    float zOff = e.z + (isPickup(e.k) ? .03f + .03f * std::sin(e.t * 3) : 0.f);
    float bottom = horizon + (camH - zOff) * FOCAL / depth, topY = bottom - H;
    float f = 1.f - std::exp(-dens * depth * (beacon ? .3f : 1.f)), inv = 1.f - f;
    int Br = (int)(fogR * f), Bg = (int)(fogG * f), Bb = (int)(fogB * f);
    int xa = std::max(0, (int)(sx - Wd / 2)), xb = std::min(SW - 1, (int)(sx + Wd / 2));
    int ya = std::max(0, (int)topY), yb = std::min(SH - 1, (int)bottom);
    float vstep = T.h / H;
    for (int x = xa; x <= xb; x++) {
      if (depth >= ZB[x]) continue;
      int tx = (int)((x - (sx - Wd / 2)) / Wd * T.w); tx = std::max(0, std::min(T.w - 1, tx)); if (flip) tx = T.w - 1 - tx;
      float L = (amb + fl * fxm[x] * std::max(0.f, 1.f - depth / 18.f)) * inv, tp = (ya - topY) * vstep;
      for (int y = ya; y <= yb; y++, tp += vstep) {
        int ty = std::max(0, std::min(T.h - 1, (int)tp)); uint32_t c = T.px[ty * T.w + tx], a = c >> 24;
        if (!a || (e.k == K_PHANTOM && ((x + y) & 1))) continue;
        uint32_t o = a == 0xFE ? lit(c, inv, Br, Bg, Bb) : lit(c, L, Br, Bg, Bb);
        if (e.hit > 0) o = lit(o, 1.f, 110, 0, 0);
        FB[y * SW + x] = o;
      }
    }
  }
  // ---- particles ----
  for (const Part& q : g.parts) {
    if (q.life <= 0) continue;
    Vec2 rel = q.pos - g.pos; float depth = dot(rel, dir); if (depth < .2f || depth > 30.f) continue;
    float sx = SW * .5f + FOCAL * dot(rel, rgt) / depth, sy = horizon + (camH - q.z) * FOCAL / depth;
    int xi = (int)sx; if ((unsigned)xi >= (unsigned)SW || depth >= ZB[xi]) continue;
    int sz = std::max(1, (int)(q.size * FOCAL / depth)); float a = std::min(1.f, q.life / (q.max * .5f));
    uint32_t col = q.glow ? q.col : lit(q.col | 0xFF000000u, amb + .15f, 0, 0, 0);
    fillRect(xi - sz / 2, (int)sy - sz / 2, sz, sz, col & 0x00FFFFFF ? (0xFF000000u | col) : col, q.grav ? 1.f : a * .6f);
  }
}

inline void drawWeapon(Game& g) {
  if (g.car >= 0) return;
  const Weapon& W = WEAP[g.cur]; const Tex& T = A.wpn[g.cur]; const int sc = 2;
  float bx = std::sin(g.bob) * (g.sprint ? 9.f : 4.f), by = std::fabs(std::cos(g.bob)) * (g.sprint ? 7.f : 3.f);
  float dip = g.sprintK * 26.f, rel = g.reloadT > 0 ? std::sin((1.f - g.reloadT / W.reload) * PI) * 70.f : 0.f;
  float px = SW / 2 + 60 - T.w * sc / 2 + bx, py = SH - T.h * sc + 6 + by + dip + rel + g.recoil * 16.f;
  if (g.cur == 3 && g.swingT > 0) { float s = std::sin((1.f - g.swingT / .3f) * PI); px -= s * 110; py -= s * 70; }
  float L = clampf(g.ambient + .3f + (g.flashT > 0 ? .5f : 0.f) + (g.flashlight ? .3f : 0.f), .3f, 1.3f);
  for (int ty = 0; ty < T.h; ty++) for (int tx = 0; tx < T.w; tx++) {
    uint32_t c = T.get(tx, ty); if (!(c >> 24)) continue;
    fillRect((int)px + tx * sc, (int)py + ty * sc, sc, sc, lit(c, L, 0, 0, 0));
  }
  if (g.flashT > 0 && g.cur < 3) {
    float cx = px + T.w * sc / 2, cy = py;
    for (int dy = -28; dy <= 28; dy++) for (int dx = -28; dx <= 28; dx++) {
      float d = std::sqrt((float)(dx * dx + dy * dy)) / 28.f; if (d < 1.f) blendPx((int)cx + dx, (int)cy + dy, d < .4f ? rgb(255, 245, 200) : rgb(255, 170, 60), (1.f - d) * .9f);
    }
  }
}

inline void post(Game& g) {
  static std::vector<float> vig;
  if (vig.empty()) { vig.resize(SW * SH); for (int y = 0; y < SH; y++) for (int x = 0; x < SW; x++) { float nx = (x / (float)SW - .5f) * 2, ny = (y / (float)SH - .5f) * 2; vig[y * SW + x] = clampf(1.f - (nx * nx * .9f + ny * ny * .9f) * .38f, .35f, 1.f); } }
  float hurtA = clampf(g.hurtT / .4f, 0.f, 1.f), low = g.hp < 35 && g.st == ST_PLAY ? (35 - g.hp) / 35.f * (.5f + .5f * std::sin((float)g.clock * 6)) : 0.f;
  uint32_t rs = g.frame * 2654435761u + 1;
  float ins = clampf(1.f - g.sanity / 60.f, 0.f, 1.f);
  for (int i = 0; i < SW * SH; i++) {
    uint32_t c = FB[i]; float k = vig[i] * (1.f - low * .5f);
    rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; int gn = (int)(rs & 15) - 8;
    int r = (int)(((c >> 16) & 255) * k) + gn, gg = (int)(((c >> 8) & 255) * k) + gn, b = (int)((c & 255) * k) + gn;
    if (hurtA > 0) { r += (int)(hurtA * 80 * (1.f - k + .3f)); gg = (int)(gg * (1.f - hurtA * .4f)); b = (int)(b * (1.f - hurtA * .4f)); }
    if (ins > 0) { int lum = (r + gg + b) / 3; r = (int)(r + (lum - r) * ins * .5f); gg = (int)(gg + (lum - gg) * ins * .5f); b = (int)(b + (lum - b) * ins * .5f) + (int)(ins * 14); }
    FB[i] = rgb(r, gg, b);
  }
  if (g.sanity < 50) {  // low sanity: the world sways
    float amp = (1.f - g.sanity / 50.f) * 5.f; static uint32_t tmp[SW];
    for (int y = 0; y < SH; y++) {
      int off = (int)(std::sin(y * .06f + (float)g.clock * 2.5f) * amp); if (!off) continue;
      std::memcpy(tmp, &FB[y * SW], sizeof tmp);
      for (int x = 0; x < SW; x++) FB[y * SW + x] = tmp[((x + off) % SW + SW) % SW];
    }
  }
}

inline void bar(int x, int y, int w, int h, float frac, uint32_t col, uint32_t back) {
  fillRect(x - 1, y - 1, w + 2, h + 2, rgb(0, 0, 0), .75f); fillRect(x, y, w, h, back); fillRect(x, y, (int)(w * clampf(frac, 0, 1)), h, col);
}
inline std::string clockStr(float h) { char b[16]; std::snprintf(b, sizeof b, "%02d:%02d", (int)h % 24, (int)((h - std::floor(h)) * 60)); return b; }

inline void drawHUD(Game& g) {
  const uint32_t white = rgb(230, 230, 225), gold = rgb(240, 200, 90), red = rgb(210, 50, 40);
  // vitals
  struct Row { const char* n; float v; uint32_t c, back; };
  Row rows[4] = {{"HEALTH", g.hp, g.hp < 35 ? red : rgb(190, 40, 36), rgb(48, 10, 10)},
                 {"ARMOR", g.armor, rgb(90, 140, 200), rgb(14, 26, 44)},
                 {"STAMINA", g.stam, g.winded ? rgb(220, 130, 30) : rgb(90, 190, 70), rgb(16, 40, 14)},
                 {"SANITY", g.sanity, rgb(150, 90, 220), rgb(30, 14, 48)}};
  for (int i = 0; i < 4; i++) { int y = SH - 60 + i * 12; drawText(14, y, rows[i].n, 1, white); bar(66, y, 100, 7, rows[i].v / 100.f, rows[i].c, rows[i].back); }
  drawText(14, SH - 74, "H MED " + std::to_string(g.meds) + "  G PILLS " + std::to_string(g.pills) + "  FUEL " + std::to_string(g.cans) + "  I INVENTORY", 1, rgb(170, 170, 160));
  // loadout bar
  static const char* shortN[4] = {"PIST", "SHOT", "CARB", "BAR"};
  for (int i = 0; i < 4; i++) {
    int x = SW / 2 - 104 + i * 52, y = SH - 38; bool sel = g.cur == i;
    fillRect(x, y, 48, 30, rgb(8, 8, 8), .7f);
    fillRect(x, y, 48, 1, sel ? gold : rgb(80, 80, 80)); fillRect(x, y + 29, 48, 1, sel ? gold : rgb(80, 80, 80));
    fillRect(x, y, 1, 30, sel ? gold : rgb(80, 80, 80)); fillRect(x + 47, y, 1, 30, sel ? gold : rgb(80, 80, 80));
    uint32_t col = !g.has[i] ? rgb(70, 70, 70) : (sel ? gold : white);
    drawText(x + 4, y + 4, std::to_string(i + 1) + " " + shortN[i], 1, col);
    if (g.has[i] && i < 3) drawText(x + 4, y + 17, std::to_string(g.mag[i]) + "/" + std::to_string(g.reserve[WEAP[i].ammo]), 1, col);
    else if (g.has[i]) drawText(x + 4, y + 17, "MELEE", 1, col);
    else drawText(x + 4, y + 17, "LOCKED", 1, col);
  }
  // ammo counter / vehicle gauge
  if (g.car >= 0) {
    drawText(SW - 150, SH - 56, "SPEED", 1, white); drawText(SW - 150, SH - 44, std::to_string((int)(g.carSpeed * 6)), 3, gold);
    drawText(SW - 150, SH - 20, "FUEL", 1, white);
    bar(SW - 112, SH - 20, 96, 8, g.w.ents[g.car].aux, rgb(230, 170, 40), rgb(40, 30, 8));
    bar(SW - 150, SH - 8, 134, 3, g.w.ents[g.car].hp / 200.f, rgb(190, 60, 50), rgb(40, 10, 10));
  } else {
    const Weapon& W = WEAP[g.cur];
    if (g.cur == 3) drawText(SW - 130, SH - 48, "MELEE", 2, white);
    else {
      drawText(SW - 150, SH - 56, g.reloadT > 0 ? "RELOADING" : W.name, 1, g.reloadT > 0 ? gold : white);
      std::string m = std::to_string(g.mag[g.cur]);
      drawText(SW - 150, SH - 44, m, 4, g.mag[g.cur] == 0 ? red : white);
      drawText(SW - 150 + (int)m.size() * 24 + 6, SH - 28, "/ " + std::to_string(g.reserve[W.ammo]), 2, rgb(180, 180, 170));
    }
  }
  // objective panel + clock
  fillRect(8, 8, 264, 44, rgb(0, 0, 0), .55f);
  drawText(14, 12, "OBJECTIVE", 1, gold);
  std::string ob = STG_NAME[std::min(g.stage, 5)];
  if (g.stage == 0) ob += " (" + std::to_string(g.cans) + "/3)";
  drawText(14, 24, ob, 1, white);
  if (g.stage == 4) { bar(14, 38, 150, 6, g.uploadT / UPLOAD_TIME, rgb(80, 190, 240), rgb(10, 30, 40)); drawText(172, 36, std::to_string((int)(g.uploadT / UPLOAD_TIME * 100)) + "%", 1, white); }
  else drawText(14, 38, "TAB - OBJECTIVES   F - LIGHT", 1, rgb(150, 150, 145));
  float left = DEADLINE_H - g.gt;
  drawText(SW - 190, 12, "DAY " + std::to_string(g.day()) + "  " + clockStr(g.tod()), 2, white);
  drawText(SW - 190, 30, "SHIP DEPARTS IN " + std::to_string((int)left) + "H", 1, left < 8 ? red : rgb(190, 190, 180));
  // compass marker
  Vec2 tgt;
  if (g.objTarget(tgt)) {
    Vec2 rel = tgt - g.pos; float d = rel.len(), delta = std::atan2(rel.y, rel.x) - g.ang;
    while (delta > PI) delta -= 2 * PI; while (delta < -PI) delta += 2 * PI;
    int mx = SW / 2 + (int)clampf(-delta / (PI * .5f) * 150.f, -150.f, 150.f);
    fillRect(SW / 2 - 160, 14, 320, 2, rgb(255, 255, 255), .25f); fillRect(SW / 2 - 1, 11, 2, 8, rgb(255, 255, 255), .5f);
    for (int i = 0; i < 5; i++) fillRect(mx - 4 + i, 10 + i, 9 - 2 * i, 1, gold);
    std::string ds = std::to_string((int)(d * 2)) + " M"; drawText(mx - textW(ds, 1) / 2, 22, ds, 1, gold);
  }
  // messages
  for (size_t i = 0; i < g.msgs.size(); i++) {
    const auto& m = g.msgs[i]; float a = clampf(m.t, 0.f, 1.f);
    int y = SH - 150 + (int)i * 12 - (int)(g.msgs.size() - 1) * 0; std::string s = m.s.size() > 100 ? m.s.substr(0, 100) : m.s;
    fillRect(12, y - 2, textW(s, 1) + 6, 11, rgb(0, 0, 0), .5f * a);
    drawText(15, y, s, 1, m.s.rfind("LANTERN", 0) == 0 || m.s.rfind("RELAY", 0) == 0 ? rgb(150, 220, 150) : white);
  }
  // crosshair
  if (g.car < 0 && !g.sprint) {
    int cx = SW / 2, cy = SH / 2; uint32_t c = rgb(235, 235, 235); int gap = 3 + (int)(g.recoil * 5);
    if (g.cur == 3) fillRect(cx - 1, cy - 1, 2, 2, c);
    else { fillRect(cx - gap - 4, cy, 4, 1, c, .8f); fillRect(cx + gap, cy, 4, 1, c, .8f); fillRect(cx, cy - gap - 4, 1, 4, c, .8f); fillRect(cx, cy + gap, 1, 4, c, .8f); }
  }
}

inline void drawObjectives(Game& g) {
  const uint32_t white = rgb(230, 230, 225), gold = rgb(240, 200, 90), dim = rgb(130, 130, 125);
  fillRect(0, 0, SW, SH, rgb(4, 4, 6), .86f);
  drawText(30, 20, "OBJECTIVES", 3, rgb(200, 50, 40));
  for (int i = 0; i < 6; i++) {
    bool done = i < g.stage, curr = i == g.stage;
    drawText(34, 56 + i * 14, std::string(done ? "[X] " : (curr ? "[>] " : "[ ] ")) + STG_NAME[i], 1, done ? dim : (curr ? gold : rgb(90, 90, 88)));
  }
  int y = 150; for (auto& ln : wrapText(STG_DESC[std::min(g.stage, 5)], 70)) { drawText(34, y, ln, 1, white); y += 11; }
  y += 8; drawText(34, y, "STATUS", 1, gold); y += 12;
  drawText(34, y, "TIME  DAY " + std::to_string(g.day()) + " " + clockStr(g.tod()) + "   SHIP DEPARTS DAY 3 06:00 (" + std::to_string((int)(DEADLINE_H - g.gt)) + "H LEFT)", 1, white); y += 11;
  drawText(34, y, "FUEL CANS " + std::to_string(g.cans) + "   POSITION " + std::to_string((int)g.pos.x) + "," + std::to_string((int)g.pos.y), 1, white);
  drawText(380, 56, "RADIO LOG", 1, gold);
  int ly = 70; size_t from = g.logLines.size() > 9 ? g.logLines.size() - 9 : 0;
  for (size_t i = from; i < g.logLines.size() && ly < SH - 40; i++) for (auto& ln : wrapText(g.logLines[i], 40)) { drawText(380, ly, ln, 1, rgb(150, 210, 150)); ly += 10; if (ly >= SH - 40) break; }
  drawText(34, SH - 34, "WASD MOVE  SHIFT SPRINT  SPACE JUMP  LMB FIRE  R RELOAD  E USE/DRIVE  F LIGHT  1-4 WEAPONS", 1, dim);
  drawText(34, SH - 22, "PRESS TAB TO RETURN", 1, gold);
}

inline const char* pickName(int k) {
  switch (k) {
    case K_AMMO9: return "9MM AMMO"; case K_AMMO12: return "SHOTGUN SHELLS"; case K_AMMO556: return "5.56 AMMO";
    case K_HEALTH: return "MEDKIT"; case K_FUEL: return "FUEL CAN"; case K_NOTE: return "NOTE";
    case K_WSHOT: return "SHOTGUN"; case K_WRIF: return "CARBINE"; case K_PILLS: return "SEDATIVES"; case K_ARMOR: return "ARMOR VEST";
  }
  return "ITEM";
}
inline void drawPrompt(Game& g) {
  if (g.car >= 0 || g.showObj || g.showInv) return;
  std::string s; Vec2 dir(std::cos(g.ang), std::sin(g.ang));
  if (g.focus >= 0 && !g.w.ents[g.focus].dead) s = std::string("PICK UP ") + pickName(g.w.ents[g.focus].k);
  else {
    for (float t = .6f; t <= 1.8f && s.empty(); t += .4f) {
      int c = g.w.cellAt((int)(g.pos.x + dir.x * t), (int)(g.pos.y + dir.y * t));
      if (c == 5) s = "OPEN DOOR"; else if (c == 6) s = "CLOSE DOOR";
    }
    if (s.empty()) for (const Ent& e : g.w.ents)
      if (!e.dead && e.k == K_CAR && std::fabs(e.pos.x - g.pos.x) < 3.4f && std::fabs(e.pos.y - g.pos.y) < 3.4f && dist(e.pos, g.pos) < 3.4f) {
        s = e.wreck ? "" : (e.hauler && !g.fueled ? "FUEL THE HAULER (NEEDS 3 CANS)" : "ENTER VEHICLE"); break; }
  }
  if (s.empty()) return;
  s = "E - " + s; int w = textW(s, 1) + 12, x = (SW - w) / 2, y = SH / 2 + 28;
  fillRect(x, y - 3, w, 14, rgb(0, 0, 0), .65f); fillRect(x, y - 3, w, 1, rgb(240, 200, 90));
  drawCentered(y, s, 1, rgb(240, 200, 90));
}
inline void blitTex(const Tex& T, int x, int y, int w, int h) {
  for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) { uint32_t c = T.get(xx * T.w / w, yy * T.h / h); if (c >> 24) fillRect(x + xx, y + yy, 1, 1, c | 0xFF000000u); }
}
inline void drawInventory(Game& g) {
  const uint32_t white = rgb(230, 230, 225), gold = rgb(240, 200, 90), dim = rgb(130, 130, 125);
  fillRect(0, 0, SW, SH, rgb(4, 4, 6), .9f);
  drawText(30, 16, "INVENTORY", 3, rgb(200, 50, 40));
  struct Slot { int spr; std::string name, val; };
  Slot slots[8] = {{S_HEALTH, "MEDKIT", "x" + std::to_string(g.meds) + " (H)"}, {S_PILLS, "SEDATIVES", "x" + std::to_string(g.pills) + " (G)"},
                   {S_FUEL, "FUEL CAN", "x" + std::to_string(g.cans)}, {S_ARMOR, "ARMOR", std::to_string((int)g.armor) + "%"},
                   {S_AMMO9, "9MM", std::to_string(g.reserve[0])}, {S_AMMO12, "12 GAUGE", std::to_string(g.reserve[1])},
                   {S_AMMO556, "5.56", std::to_string(g.reserve[2])}, {S_NOTE, "JOURNAL", std::to_string(g.journal.size()) + " NOTES"}};
  for (int i = 0; i < 8; i++) {
    int x = 30 + (i % 4) * 100, y = 56 + (i / 4) * 96;
    fillRect(x, y, 92, 88, rgb(24, 24, 26), .9f); fillRect(x, y, 92, 1, rgb(90, 90, 90));
    blitTex(A.spr[slots[i].spr], x + 26, y + 6, 40, 40);
    drawText(x + 6, y + 56, slots[i].name, 1, white); drawText(x + 6, y + 70, slots[i].val, 1, gold);
  }
  drawText(440, 56, "LOADOUT", 1, gold);
  for (int i = 0; i < 4; i++) {
    std::string s = std::to_string(i + 1) + " " + WEAP[i].name; uint32_t c = !g.has[i] ? rgb(70, 70, 70) : (g.cur == i ? gold : white);
    drawText(440, 74 + i * 24, s, 1, c);
    drawText(440, 86 + i * 24, !g.has[i] ? "NOT FOUND" : (i == 3 ? "MELEE" : std::to_string(g.mag[i]) + " / " + std::to_string(g.reserve[WEAP[i].ammo])), 1, dim);
  }
  drawText(440, 180, "VITALS", 1, gold);
  drawText(440, 194, "HEALTH " + std::to_string((int)g.hp) + "  ARMOR " + std::to_string((int)g.armor), 1, white);
  drawText(440, 206, "SANITY " + std::to_string((int)g.sanity) + "  STAMINA " + std::to_string((int)g.stam), 1, white);
  drawText(30, 252, "JOURNAL", 1, gold);
  int y = 264; size_t from = g.journal.size() > 3 ? g.journal.size() - 3 : 0;
  for (size_t i = from; i < g.journal.size(); i++) for (auto& ln : wrapText(g.journal[i], 96)) { if (y > SH - 36) break; drawText(30, y, ln, 1, rgb(150, 210, 150)); y += 10; }
  if (g.journal.empty()) drawText(30, 264, "NO NOTES FOUND YET.", 1, dim);
  drawText(30, SH - 22, "H USE MEDKIT   G USE SEDATIVES   I CLOSE", 1, gold);
}

inline void drawMinimap(Game& g) {
  const int S = 100, x0 = SW - S - 12, y0 = 46; const float sc = .6f;  // 0.6 world units per pixel, heading-up
  const float ca = std::cos(g.ang), sa = std::sin(g.ang); const Vec2 fwd(ca, sa), rgt(sa, -ca);
  fillRect(x0 - 2, y0 - 2, S + 4, S + 4, rgb(0, 0, 0), .75f);
  for (int py = 0; py < S; py++) for (int px = 0; px < S; px++) {
    Vec2 p = g.pos + fwd * ((S / 2 - py) * sc) + rgt * ((px - S / 2) * sc);
    int cx = (int)std::floor(p.x), cy = (int)std::floor(p.y); uint32_t c;
    if (!g.w.in(cx, cy)) c = rgb(8, 8, 8);
    else {
      int cv = g.w.cell[cy * MW + cx], gd = g.w.ground[cy * MW + cx];
      if (cv == 8) c = rgb(52, 48, 48); else if (cv == 5) c = rgb(210, 150, 60); else if (cv == 6) c = rgb(120, 100, 60);
      else if (cv) c = rgb(156, 146, 136); else c = gd == 3 ? rgb(88, 88, 92) : (gd == 5 ? rgb(66, 56, 48) : rgb(34, 40, 28));
    }
    blendPx(x0 + px, y0 + py, c, .9f);
  }
  auto marker = [&](Vec2 world, uint32_t col, int size, float maxDist) {
    Vec2 rel = world - g.pos; if (rel.len() > maxDist) return;
    float mx = dot(rel, rgt) / sc, my = -dot(rel, fwd) / sc; bool inside = std::fabs(mx) < S / 2 - 3 && std::fabs(my) < S / 2 - 3;
    if (!inside) { float k = (S / 2 - 4) / std::max(std::fabs(mx), std::fabs(my)); mx *= k; my *= k; size = std::max(2, size - 2); }
    int sx = x0 + S / 2 + (int)mx, sy = y0 + S / 2 + (int)my;
    fillRect(sx - size / 2 - 1, sy - size / 2 - 1, size + 2, size + 2, rgb(0, 0, 0)); fillRect(sx - size / 2, sy - size / 2, size, size, col);
  };
  float pulse = .65f + .35f * std::sin((float)g.clock * 5.f);
  for (const Ent& e : g.w.ents) if (!e.dead && e.k == K_FUEL) marker(e.pos, rgb((int)(255 * pulse), (int)(150 * pulse), 20), 5, 90.f);
  Vec2 tgt; if (g.objTarget(tgt)) marker(tgt, rgb(240, 210, 90), 6, 1e9f);
  for (int i = 0; i < 6; i++) fillRect(x0 + S / 2 - i / 2, y0 + S / 2 - 3 + i, 1 + i, 1, rgb(255, 255, 255));  // player arrow (always points up)
  fillRect(x0, y0 + S + 4, 6, 6, rgb(255, 150, 20)); drawText(x0 + 9, y0 + S + 4, "FUEL", 1, rgb(230, 230, 225));
  fillRect(x0 + 48, y0 + S + 4, 6, 6, rgb(240, 210, 90)); drawText(x0 + 57, y0 + S + 4, "GOAL", 1, rgb(230, 230, 225));
}

inline void drawScreens(Game& g) {
  const uint32_t white = rgb(230, 230, 225), gold = rgb(240, 200, 90);
  if (g.st == ST_TITLE) {
    fillRect(0, 0, SW, SH, rgb(0, 0, 0), .78f);
    drawCentered(34, "ASHFALL", 8, rgb(190, 35, 30)); drawCentered(104, "THE LAST COURIER", 2, white);
    static const char* story = "2041. THE BLOOM SWEPT THE BASIN IN NINE DAYS AND THE DEAD DID NOT STAY DOWN. YOU ARE WREN, THE LAST COURIER OF OUTPOST NINE. ON THE RADIO, A VOICE CALLED LANTERN KEEPS REPEATING ONE MESSAGE FROM THE RELAY AT CINDER RIDGE: A FERRY LEAVES PORT MARROW AT DAWN ON DAY THREE. IT WILL NOT WAIT. YOU HAVE A DRY TRUCK, A PISTOL, AND A BASIN FULL OF HOLLOWS THAT HUNT BY SOUND AND GATHER UNDER LIGHT.";
    int y = 140; for (auto& ln : wrapText(story, 84)) { drawCentered(y, ln, 1, white); y += 12; }
    drawCentered(y + 14, "WASD MOVE   MOUSE LOOK   SHIFT SPRINT   SPACE JUMP   LMB FIRE   R RELOAD", 1, rgb(160, 160, 155));
    drawCentered(y + 26, "E PICK UP/USE   F LIGHT   H MEDKIT   G SEDATIVES   I INVENTORY   TAB OBJECTIVES   M MAP   ESC QUIT", 1, rgb(160, 160, 155));
    if (((int)(SDL_GetTicks() / 500)) & 1) drawCentered(SH - 40, "PRESS ENTER TO BEGIN", 2, gold);
  } else if (g.st == ST_DEAD) {
    fillRect(0, 0, SW, SH, rgb(40, 0, 0), .7f); drawCentered(120, "YOU DIED", 8, rgb(200, 30, 30));
    drawCentered(200, "THE ASH TAKES ANOTHER COURIER.", 1, white); drawCentered(230, "PRESS R TO TRY AGAIN", 2, gold);
  } else if (g.st == ST_WIN) {
    fillRect(0, 0, SW, SH, rgb(0, 0, 0), .75f); drawCentered(100, "THE FERRY HORN", 5, gold);
    int y = 170; for (auto& ln : wrapText("THE HORN CUTS THROUGH THE ASH. LANTERN'S SIGNAL HELD. ON THE DECK, STRANGERS REACH DOWN TO PULL YOU ABOARD. BEHIND YOU THE BASIN BURNS RED AND QUIET. YOU ARE NOT THE LAST ONE AFTER ALL.", 80)) { drawCentered(y, ln, 1, white); y += 12; }
    drawCentered(y + 20, "PRESS R TO PLAY AGAIN", 2, gold);
  } else if (g.st == ST_LOSE) {
    fillRect(0, 0, SW, SH, rgb(0, 0, 0), .8f); drawCentered(100, "TOO LATE", 6, rgb(200, 30, 30));
    drawCentered(170, "DAWN COMES. THE HARBOR IS EMPTY. THE HOLLOW REMAIN.", 1, white); drawCentered(210, "PRESS R TO TRY AGAIN", 2, gold);
  }
}

inline void renderScene(Game& g) {
  renderWorld(g); drawWeapon(g); post(g);
  if (g.st == ST_PLAY || g.st == ST_DEAD) drawHUD(g);
  if (g.st == ST_PLAY) drawPrompt(g);
  if (g.st == ST_PLAY && g.showMap && !g.showObj && !g.showInv) drawMinimap(g);
  if (g.showInv && g.st == ST_PLAY) drawInventory(g);
  if (g.showObj && g.st == ST_PLAY) drawObjectives(g);
  drawScreens(g);
}

#pragma once
#include "audio.h"
#include "world.h"

constexpr float DAY_LEN = 1200.f;      // real seconds per in-game day
constexpr float UPLOAD_TIME = 75.f;   // seconds to hold the relay
constexpr float DEADLINE_H = 54.f;    // ship leaves day 3, 06:00
constexpr float GRACE = 180.f;       // no roaming spawns for the first 3 minutes
constexpr float START_H = 7.0f;       // game starts in the early morning

struct Weapon { const char* name; int mag; float rof, dmg, spread, recoil, reload, range; int pellets, ammo; bool autoF; };
inline const Weapon WEAP[4] = {
  {"PISTOL", 15, 0.17f, 28, 0.015f, 0.05f, 1.2f, 45, 1, 0, false},
  {"SHOTGUN", 2, 0.50f, 14, 0.085f, 0.14f, 1.8f, 25, 9, 1, false},
  {"CARBINE", 30, 0.09f, 22, 0.025f, 0.035f, 1.9f, 60, 1, 2, true},
  {"CROWBAR", 0, 0.60f, 36, 0, 0, 0, 1.7f, 1, -1, false}};

inline const char* STG_NAME[6] = {"FIND 3 FUEL CANS", "FUEL THE HAULER AT OUTPOST NINE", "DRIVE TO THE CINDER RIDGE RELAY",
                                  "ACTIVATE THE RELAY", "SURVIVE THE UPLOAD", "REACH PORT MARROW BEFORE DAWN"};
inline const char* STG_DESC[6] = {
  "THE HAULER AT OUTPOST NINE IS BONE DRY. THE TOWNS OF THE BASIN STILL HOLD FUEL IN THEIR GARAGES AND CELLARS. SEARCH THE RUINS AND PRESS E TO PICK THINGS UP. CLOSE DOORS BEHIND YOU - THEY CANNOT WORK A HANDLE.",
  "YOU HAVE ENOUGH FUEL. GO BACK TO THE HAULER AT OUTPOST NINE AND PRESS E NEXT TO IT.",
  "THE RELAY MUST SEND OUR COORDINATES OR THE SHIP WILL NOT DOCK. FOLLOW THE COMPASS MARKER. THE RED BEACON ON THE TOWER CAN BE SEEN FROM FAR AWAY.",
  "STAND AT THE FOOT OF THE TOWER AND PRESS E TO THROW THE BREAKER. IT WILL DRAW EVERYTHING FOR KILOMETRES.",
  "HOLD THE RELAY UNTIL THE UPLOAD FINISHES. STAY NEAR THE TOWER. THE HUT MAKES GOOD COVER.",
  "THE FERRY LEAVES AT DAWN ON DAY THREE. DRIVE TO PORT MARROW. ITS LIGHTS CAN BE SEEN ACROSS THE ASH."};

struct Part { Vec2 pos, vel; float z = 0, vz = 0, life = 0, max = 1, size = 0.03f; uint32_t col = 0; bool grav = true, glow = false; };
enum State { ST_TITLE, ST_PLAY, ST_DEAD, ST_WIN, ST_LOSE };

struct Game {
  World w; Audio au; State st = ST_TITLE; bool showObj = false, showInv = false, showMap = true; uint32_t seedSaved = 1337;
  Vec2 pos, vel; float ang = 0, pitch = 0, kick = 0, z = 0, vz = 0, hp = 100, stam = 100, stamDelay = 0;
  bool winded = false, sprint = false; float sprintK = 0;
  int cur = 0, mag[4] = {15, 2, 0, 0}, reserve[3] = {30, 6, 0}; bool has[4] = {true, false, false, true};
  float cd = 0, reloadT = 0, recoil = 0, flashT = 0, hurtT = 0, swingT = 0, bob = 0, shake = 0, noiseT = 0, beatT = 0;
  bool flashlight = false, fireHeld = false, jumpReq = false; int cans = 0, car = -1;
  float armor = 0, sanity = 100, phantomT = 0; int meds = 0, pills = 0, focus = -1; std::vector<std::string> journal;
  double clock = 0; float gt = START_H, sunSin = 0, daylight = 0.65f, ambient = 0.6f;
  int stage = 0; float uploadT = 0; bool fueled = false;
  std::vector<std::string> logLines;
  struct Msg { std::string s; float t; }; std::vector<Msg> msgs;
  std::vector<Part> parts; size_t partHead = 0;
  std::vector<int> actList;
  struct Drop { Kind k; Vec2 p; }; std::vector<Drop> drops;
  float spawnT = 0, mouseDX = 0, mouseDY = 0, carSpeed = 0; uint32_t frame = 0; RNG R{99};

  float tod() const { return std::fmod(gt, 24.f); }
  int day() const { return 1 + (int)(gt / 24.f); }

  void init(uint32_t seed) { seedSaved = seed; A.init(); au.init(); reset(); }
  void reset() {
    w.generate(seedSaved);
    pos = w.start; vel = Vec2(); ang = 0.4f; pitch = kick = z = vz = 0; hp = 100; stam = 100; stamDelay = 0;
    winded = sprint = false; sprintK = 0; cur = 0;
    mag[0] = 15; mag[1] = 2; mag[2] = 0; mag[3] = 0; reserve[0] = 30; reserve[1] = 6; reserve[2] = 0;
    has[0] = true; has[1] = false; has[2] = false; has[3] = true;
    cd = reloadT = recoil = flashT = hurtT = swingT = bob = shake = noiseT = beatT = 0;
    flashlight = false; cans = 0; car = -1; clock = 0; gt = START_H; stage = 0; uploadT = 0; fueled = false;
    logLines.clear(); msgs.clear(); parts.clear(); partHead = 0; actList.clear(); drops.clear(); spawnT = 0;
    au.setEngine(0, 40);
    armor = 0; sanity = 100; phantomT = 0; meds = 0; pills = 0; focus = -1; journal.clear(); showInv = false;
    radio("LANTERN: ...WREN? IF YOU CAN HEAR THIS, THE SHIP IS REAL. PORT MARROW, DAWN OF DAY THREE. THE HAULER NEEDS FUEL.");
    say("THE BASIN IS QUIET... FOR NOW. SEARCH THE SHED FIRST.");
  }
  void say(const std::string& s) { msgs.push_back({s, 7.f}); if (msgs.size() > 5) msgs.erase(msgs.begin()); }
  void radio(const std::string& s) { logLines.push_back(s); say(s); }

  // ---------- particles ----------
  void emit(Vec2 p, float zz, Vec2 v, float vzz, float life, uint32_t col, float size, bool grav = true, bool gl = false) {
    Part q; q.pos = p; q.z = zz; q.vel = v; q.vz = vzz; q.life = q.max = life; q.col = col; q.size = size; q.grav = grav; q.glow = gl;
    if (parts.size() < 700) parts.push_back(q); else parts[partHead++ % 700] = q;
  }
  void bloodAt(Vec2 p, float zz, int n) { for (int i = 0; i < n; i++) emit(p, zz, Vec2(R.r(-1.5f, 1.5f), R.r(-1.5f, 1.5f)), R.r(0.5f, 2.f), R.r(.5f, 1.1f), rgb(140, 14, 14), .03f); }
  void sparksAt(Vec2 p, int n) { for (int i = 0; i < n; i++) emit(p, R.r(.3f, .6f), Vec2(R.r(-1.5f, 1.5f), R.r(-1.5f, 1.5f)), R.r(0.5f, 2.f), R.r(.15f, .35f), glowc(255, 190, 90), .025f, true, true); }

  // ---------- combat ----------
  void hurt(float d) {
    if (st != ST_PLAY) return;
    float ab = std::min(armor, d * .6f); armor -= ab; d -= ab;
    hp -= d; hurtT = .4f; shake += .3f; au.play(Audio::HURT, .9f); sanity = std::max(0.f, sanity - 1.5f);
    if (hp <= 0) { hp = 0; st = ST_DEAD; au.setEngine(0, 40); showObj = false; }
  }
  void explode(Vec2 c) {
    au.play(Audio::BOOM, 1.f);
    float dp = dist(pos, c); if (dp < 20) shake += 0.9f * (1.f - dp / 20.f);
    for (int i = 0; i < 50; i++) emit(c, R.r(.1f, .8f), Vec2(R.r(-3, 3), R.r(-3, 3)), R.r(1, 4), R.r(.4f, 1.1f), glowc(255, (int)R.r(80, 200), 30), .09f, true, true);
    for (int i = 0; i < 30; i++) emit(c, R.r(.2f, .8f), Vec2(R.r(-1, 1), R.r(-1, 1)), R.r(.8f, 1.6f), R.r(1.5f, 3.f), rgb(50, 50, 50), .16f, false);
    for (int i = 0; i < (int)w.ents.size(); i++) {
      Ent& e = w.ents[i]; if (e.dead) continue;
      float d = dist(e.pos, c); if (d > 5.5f) continue;
      float f = 1.f - d / 5.5f; Vec2 n = d > .01f ? (e.pos - c) * (1.f / d) : Vec2(1, 0);
      if (isEnemy(e.k)) damageEnt(i, 170 * f, n * (9 * f));
      else if (e.k == K_BARREL || e.k == K_XBARREL) damageEnt(i, 60 * f, n * (10 * f));
      else if (e.k == K_CAR) { e.vel = e.vel + n * (6 * f); e.hp -= 60 * f; }
    }
    if (dp < 5.5f) hurt(70 * (1.f - dp / 5.5f));
  }
  void damageEnt(int i, float dmg, Vec2 push) {
    Ent& e = w.ents[i]; if (e.dead) return;
    if (isEnemy(e.k)) {
      e.hp -= dmg; e.hit = .12f; e.vel = e.vel + push; e.alert = true; e.active = true; bloodAt(e.pos, .5f, 5);
      if (e.hp <= 0) {
        if (R.f() < .18f) drops.push_back({R.f() < .5f ? K_AMMO9 : (R.f() < .5f ? K_HEALTH : K_AMMO12), e.pos});
        Kind ok = e.k; e.k = K_CORPSE; e.tex = ok == K_BRUTE ? S_CORPSE_B : (ok == K_RUNNER ? S_CORPSE_R : S_CORPSE);
        e.scale = ok == K_BRUTE ? .3f : .22f; e.t = 0; e.r = 0; e.vel = Vec2(); au.play(Audio::HIT, .5f);
      }
    } else if (e.k == K_BARREL) { e.hp -= dmg; e.vel = e.vel + push * .6f; sparksAt(e.pos, 3); }
    else if (e.k == K_XBARREL) {
      e.hp -= dmg; e.vel = e.vel + push * .3f; sparksAt(e.pos, 3);
      if (e.hp <= 0) { Vec2 c = e.pos; w.kill(i); explode(c); }
    }
  }
  void hitscan(float a, float dmg, float range, float kickf) {
    Vec2 d(std::cos(a), std::sin(a));
    RayHit h = castRay(w, pos, d, range); float bt = h.dist; int best = -1;
    for (int i = 0; i < (int)w.ents.size(); i++) {
      const Ent& e = w.ents[i]; if (e.dead || !(isEnemy(e.k) || e.k == K_BARREL || e.k == K_XBARREL)) continue;
      Vec2 rel = e.pos - pos; float t = dot(rel, d); if (t < .2f || t > bt) continue;
      if (std::fabs(cross2(rel, d)) < e.r * .9f + .08f) { best = i; bt = t; }
    }
    if (best >= 0) damageEnt(best, dmg * (R.f() < .12f ? 2.f : 1.f), d * kickf);
    else if (h.hit) sparksAt(pos + d * (h.dist - .05f), 3);
  }
  void reload() {
    const Weapon& W = WEAP[cur];
    if (cur == 3 || reloadT > 0 || mag[cur] >= W.mag) return;
    if (reserve[W.ammo] <= 0) { say("NO AMMO"); return; }
    reloadT = W.reload; au.play(Audio::RELOAD, .8f);
  }
  void finishReload() { const Weapon& W = WEAP[cur]; int take = std::min(W.mag - mag[cur], reserve[W.ammo]); mag[cur] += take; reserve[W.ammo] -= take; }
  void selectWeapon(int i) { if (i == cur || !has[i] || car >= 0) return; cur = i; reloadT = 0; cd = .25f; say(WEAP[i].name); }
  void tryFire() {
    const Weapon& W = WEAP[cur]; Vec2 dir(std::cos(ang), std::sin(ang)), rgt(std::sin(ang), -std::cos(ang));
    if (cur == 3) {
      cd = W.rof; swingT = .3f; au.play(Audio::SWING, .7f); noiseT = .8f;
      for (int i = 0; i < (int)w.ents.size(); i++) {
        const Ent& e = w.ents[i]; if (e.dead || !(isEnemy(e.k) || e.k == K_BARREL || e.k == K_XBARREL)) continue;
        Vec2 rel = e.pos - pos; float t = dot(rel, dir);
        if (t > 0 && t < W.range + e.r && std::fabs(dot(rel, rgt)) < .5f + e.r) { damageEnt(i, W.dmg, dir * 4.f); au.play(Audio::HIT, .8f); break; }
      }
      return;
    }
    if (mag[cur] <= 0) { cd = .3f; reload(); return; }
    mag[cur]--; cd = W.rof; recoil = 1.f; flashT = .06f; noiseT = 3.f; kick += W.recoil * 200.f; shake += cur == 1 ? .35f : .1f;
    au.play(cur == 0 ? Audio::SHOT9 : cur == 1 ? Audio::SHOTSG : Audio::SHOTRF, .9f);
    for (int p = 0; p < W.pellets; p++) hitscan(ang + (R.f() + R.f() - 1.f) * W.spread, W.dmg, W.range, cur == 1 ? 1.5f : 1.f);
    emit(pos + rgt * .25f, .4f, rgt * R.r(1.2f, 2.f) + dir * .3f, R.r(1.5f, 2.5f), 1.5f, cur == 1 ? rgb(170, 30, 24) : rgb(210, 170, 70), .02f);
    if (mag[cur] == 0 && reserve[W.ammo] > 0) reload();
  }

  // ---------- world interaction ----------
  void pickup(int i) {
    Ent& e = w.ents[i];
    switch (e.k) {
      case K_AMMO9: { int n = R.i(10, 18); reserve[0] += n; say("+" + std::to_string(n) + " 9MM"); break; }
      case K_AMMO12: { int n = R.i(3, 6); reserve[1] += n; say("+" + std::to_string(n) + " 12 GAUGE SHELLS"); break; }
      case K_AMMO556: { int n = R.i(12, 24); reserve[2] += n; say("+" + std::to_string(n) + " 5.56 ROUNDS"); break; }
      case K_HEALTH: if (meds >= 5) { say("INVENTORY FULL (MEDKITS)"); return; } meds++; say("MEDKIT ADDED - PRESS H TO USE"); break;
      case K_PILLS: if (pills >= 5) { say("INVENTORY FULL (SEDATIVES)"); return; } pills++; say("SEDATIVES ADDED - PRESS G TO USE"); break;
      case K_ARMOR: if (armor >= 99.f) { say("ARMOR ALREADY FULL"); return; } armor = std::min(100.f, armor + 50.f); say("ARMOR VEST EQUIPPED"); break;
      case K_FUEL: if (cans >= 6) { say("INVENTORY FULL (FUEL)"); return; } cans++; say("FUEL CAN " + std::to_string(cans)); break;
      case K_NOTE: { std::string s = LORE[(int)e.aux % NLORE]; journal.push_back(s); say(s); break; }
      case K_WSHOT: has[1] = true; reserve[1] += 4; say("SHOTGUN FOUND - PRESS 2"); break;
      case K_WRIF: has[2] = true; reserve[2] += 30; say("CARBINE FOUND - PRESS 3"); break;
      default: return;
    }
    au.play(Audio::PICKUP, .6f); w.kill(i);
  }
  void useMed() {
    if (st != ST_PLAY) return;
    if (meds <= 0) { say("NO MEDKITS"); return; }
    if (hp >= 99.f) { say("HEALTH ALREADY FULL"); return; }
    meds--; hp = std::min(100.f, hp + 45.f); au.play(Audio::PICKUP, .7f); say("MEDKIT USED +45 HP");
  }
  void usePills() {
    if (st != ST_PLAY) return;
    if (pills <= 0) { say("NO SEDATIVES"); return; }
    if (sanity >= 99.f) { say("MIND ALREADY CLEAR"); return; }
    pills--; sanity = std::min(100.f, sanity + 35.f); au.play(Audio::PICKUP, .7f); say("SEDATIVES TAKEN +35 SANITY");
  }
  void exitCar() {
    Ent& c = w.ents[car]; c.pos = pos; c.vel = vel; c.ang = ang;
    Vec2 rgt(std::sin(ang), -std::cos(ang)), dir(std::cos(ang), std::sin(ang));
    Vec2 tries[3] = {pos + rgt * 1.5f, pos - rgt * 1.5f, pos - dir * 2.f};
    for (auto& t : tries) if (!w.blockedCircle(t, .3f)) { pos = t; break; }
    vel = Vec2(); car = -1; au.setEngine(0, 40); carSpeed = 0;
  }
  void interact() {
    if (st != ST_PLAY) return;
    if (car >= 0) { exitCar(); return; }
    if (focus >= 0 && focus < (int)w.ents.size() && !w.ents[focus].dead && isPickup(w.ents[focus].k)) { pickup(focus); return; }
    Vec2 dir(std::cos(ang), std::sin(ang));
    int bi = -1; float bd = 3.4f;
    for (int i = 0; i < (int)w.ents.size(); i++) if (!w.ents[i].dead && w.ents[i].k == K_CAR) { float d = dist(w.ents[i].pos, pos); if (d < bd) { bd = d; bi = i; } }
    if (bi >= 0) {
      Ent& c = w.ents[bi];
      if (c.hauler && !fueled) {
        if (cans >= 3) { fueled = true; c.aux = 1.f; cans -= 3; stage = 2; au.play(Audio::PICKUP);
          radio("LANTERN: GOOD. THE RELAY AT CINDER RIDGE MUST SEND OUR COORDINATES. FOLLOW THE COMPASS. DRIVE CAREFULLY - THEY HEAR ENGINES."); }
        else say("THE HAULER IS DRY. NEED 3 FUEL CANS (" + std::to_string(cans) + "/3)");
        return;
      }
      if (c.wreck) { say("WRECKED. NOTHING LEFT TO DRIVE."); return; }
      if (c.aux < .3f && cans > 0) { cans--; c.aux = std::min(1.f, c.aux + .4f); say("USED 1 FUEL CAN"); }
      if (c.aux <= .01f) { say("OUT OF FUEL. CARRY A FUEL CAN TO REFUEL."); return; }
      car = bi; pos = c.pos; vel = c.vel; sprint = false; reloadT = 0;
      say("W/S THROTTLE  A/D STEER  SPACE HANDBRAKE  E EXIT"); return;
    }
    if (stage == 3 && dist(pos, w.tower) < 8) {
      stage = 4; uploadT = 0; au.play(Audio::BOOM, .6f);
      radio("RELAY: UPLOAD STARTED. HOLD THE TOWER. THE NOISE WILL DRAW THEM."); return;
    }
    for (float t = .6f; t <= 1.8f; t += .4f) {
      int cx = (int)(pos.x + dir.x * t), cy = (int)(pos.y + dir.y * t), c = w.cellAt(cx, cy);
      if (c == 5) { w.cell[cy * MW + cx] = 6; au.play(Audio::DOOR, .7f); return; }
      if (c == 6 && dist(pos, Vec2(cx + .5f, cy + .5f)) > .8f) { w.cell[cy * MW + cx] = 5; au.play(Audio::DOOR, .7f); return; }
    }
  }
  bool objTarget(Vec2& t) const {
    switch (stage) {
      case 1: if (w.haulerIdx >= 0) { t = w.ents[w.haulerIdx].pos; return true; } return false;
      case 2: case 3: case 4: t = w.tower; return true;
      case 5: t = w.harbor; return true;
    }
    return false;
  }

  // ---------- simulation ----------
  void pushOut(Vec2& p, Vec2& v, float r, int self, bool driving) {
    for (int i = 0; i < (int)w.ents.size(); i++) {
      Ent& e = w.ents[i]; if (e.dead || i == self || !isSolidKind(e.k)) continue;
      Vec2 d = p - e.pos; if (std::fabs(d.x) > 4 || std::fabs(d.y) > 4) continue;
      float dd = d.len(), mn = r + e.r; if (dd >= mn || dd < 1e-4f) continue;
      Vec2 n = d * (1.f / dd);
      if (e.k == K_BARREL || e.k == K_XBARREL) {
        float sp = std::max(0.f, -dot(v, n));
        e.vel = e.vel - n * (sp * 1.1f + .6f); e.pos = e.pos - n * ((mn - dd) * .7f); p = p + n * ((mn - dd) * .3f);
      } else {
        p = p + n * (mn - dd); float vn = dot(v, n);
        if (vn < 0) { v = v - n * vn; if (driving && -vn > 5.f && car >= 0) { w.ents[car].hp -= -vn * 4; shake += .4f; au.play(Audio::HIT, .9f); } }
      }
    }
  }
  void updateEnemy(Ent& e, int idx, float dt) {
    Vec2 to = pos - e.pos; float d = to.len();
    float sp = e.k == K_ZOMBIE ? 1.25f : (e.k == K_RUNNER ? 3.5f : 1.8f);
    float detect = 12 + (sprint ? 8 : 0) + (noiseT > 0 ? 30 : 0) + (flashlight ? 7 : 0) + (car >= 0 ? 25 : 0);
    if (!e.alert && d < detect) { e.alert = true; au.play(R.f() < .5f ? Audio::GROAN1 : Audio::GROAN2, clampf(1.f - d / 30.f, 0, 1) * .8f); }
    if (e.alert && d > 70) e.alert = false;
    Vec2 mv;
    if (e.alert) {
      mv = to * (1.f / std::max(d, .01f)) * (sp * (.85f + .3f * std::sin(e.t * 2 + idx)));
      if (d < e.r + .6f) {
        mv = Vec2(); e.atk -= dt;
        if (e.atk <= 0) { e.atk = e.k == K_BRUTE ? 1.4f : .9f; hurt(e.k == K_BRUTE ? 28.f : (e.k == K_RUNNER ? 9.f : 12.f)); }
      }
      if (d < 25 && R.f() < dt * .12f) au.play(R.f() < .5f ? Audio::GROAN1 : Audio::GROAN2, clampf(1.f - d / 25.f, 0, 1) * .7f);
    } else {
      e.aux -= dt;
      if (e.aux <= 0) { e.aux = R.r(2, 6); e.ang = R.r(0, 2 * PI); e.aux2 = R.f() < .4f ? 0.f : 1.f; }
      mv = Vec2(std::cos(e.ang), std::sin(e.ang)) * (.45f * e.aux2);
    }
    w.moveCircle(e.pos, (mv + e.vel) * dt, e.r); e.vel = e.vel * std::exp(-7 * dt);
  }
  void updateEnts(float dt) {
    actList.clear(); focus = -1; float fbest = 1e9f; Vec2 fdir(std::cos(ang), std::sin(ang));
    for (int i = 0; i < (int)w.ents.size(); i++) {
      Ent& e = w.ents[i]; if (e.dead) continue;
      e.t += dt; if (e.hit > 0) e.hit -= dt;
      float dx = e.pos.x - pos.x, dy = e.pos.y - pos.y, d2 = dx * dx + dy * dy;
      if (isEnemy(e.k)) {
        if (!e.active) { if (d2 < 45 * 45) e.active = true; else continue; }
        if (e.dyn && d2 > 80 * 80) { w.kill(i); continue; }
        actList.push_back(i); updateEnemy(e, i, dt);
      } else if (e.k == K_CORPSE) {
        if (e.t > 240 || d2 > 90 * 90) w.kill(i);
        else if (d2 < 400 && R.f() < dt * .6f) emit(e.pos, .12f, Vec2(R.r(-.1f, .1f), R.r(-.1f, .1f)), R.r(.2f, .4f), 2.f, glowc(255, 190, 90), .015f, false, true);  // drifting spores
      }
      else if (e.k == K_BARREL || e.k == K_XBARREL || (e.k == K_CAR && i != car)) {
        if (d2 < 60 * 60 && e.vel.len() > .02f) {
          int m = w.moveCircle(e.pos, e.vel * dt, e.r * .8f);
          if (m & 1) e.vel.x *= -.3f; if (m & 2) e.vel.y *= -.3f;
          e.vel = e.vel * std::exp(-(e.k == K_CAR ? 2.f : 3.f) * dt);
        }
        if (e.k == K_CAR && e.hp <= 0 && !e.wreck) { Vec2 c = e.pos; w.kill(i); explode(c); }
      } else if (e.k == K_PHANTOM) {
        if (e.t > 3.5f || d2 < 6.25f) { if (d2 < 6.25f) { sanity = std::max(0.f, sanity - 8.f); au.play(Audio::GROAN2, .7f); } w.kill(i); }
      } else if (isPickup(e.k) && car < 0 && st == ST_PLAY && d2 < 3.6f) {
        float d = std::sqrt(d2), facing = d < .8f ? 1.f : (dx * fdir.x + dy * fdir.y) / d;
        if (facing > .35f && d < fbest) { fbest = d; focus = i; }
      }
    }
    for (size_t a = 0; a < actList.size(); a++) for (size_t b = a + 1; b < actList.size(); b++) {
      Ent& p = w.ents[actList[a]]; Ent& q = w.ents[actList[b]];
      Vec2 d = p.pos - q.pos; float dd = d.len(), mn = p.r + q.r;
      if (dd < mn && dd > 1e-4f) { Vec2 push = d * ((mn - dd) * .5f / dd); w.moveCircle(p.pos, push, p.r); w.moveCircle(q.pos, push * -1.f, q.r); }
    }
  }
  void updateParts(float dt) {
    for (auto& q : parts) {
      if (q.life <= 0) continue; q.life -= dt;
      if (q.grav) q.vz -= 9 * dt;
      q.z += q.vz * dt; if (q.z < 0) { q.z = 0; q.vz *= -.3f; q.vel = q.vel * .5f; }
      Vec2 np = q.pos + q.vel * dt; if (!w.solid((int)np.x, (int)np.y)) q.pos = np; else q.vel = Vec2();
    }
  }
  void spawner(float dt) {
    spawnT -= dt; if (spawnT > 0) return; spawnT = .8f;
    if (clock < GRACE) return;
    int cnt = 0; for (int i : actList) if (w.ents[i].dyn) cnt++;
    int target = (int)(2 + 16 * (1.f - daylight) + (stage == 4 ? 18 : 0));
    if (cnt >= target) return;
    Vec2 dir(std::cos(ang), std::sin(ang));
    for (int a = 0; a < 8; a++) {
      float an = R.r(0, 2 * PI), d = R.r(24, 38); Vec2 p = pos + Vec2(std::cos(an), std::sin(an)) * d;
      int cx = (int)p.x, cy = (int)p.y; if (!w.in(cx, cy) || w.solid(cx, cy) || w.indoor[cy * MW + cx]) continue;
      Vec2 u = (p - pos) * (1.f / d); RayHit h = castRay(w, pos, u, d);
      if (!h.hit && dot(u, dir) > .4f) continue;  // never pop in front of the player
      float f = R.f(); Kind k = K_ZOMBIE;
      if (daylight > .4f) k = f < .9f ? K_ZOMBIE : K_RUNNER; else k = f < .55f ? K_ZOMBIE : (f < .9f ? K_RUNNER : K_BRUTE);
      if (stage == 4 && f > .5f) k = K_RUNNER;
      int id = w.add(k, p); Ent& e = w.ents[id]; e.dyn = true; e.active = true; e.alert = R.f() < .5f; break;
    }
  }
  void drive(float dt, const Uint8* ks) {
    Ent& c = w.ents[car];
    float th = (ks[SDL_SCANCODE_W] || ks[SDL_SCANCODE_UP] ? 1.f : 0.f) - (ks[SDL_SCANCODE_S] || ks[SDL_SCANCODE_DOWN] ? 1.f : 0.f);
    float steer = (ks[SDL_SCANCODE_A] ? 1.f : 0.f) - (ks[SDL_SCANCODE_D] ? 1.f : 0.f);
    bool hb = ks[SDL_SCANCODE_SPACE], fuel = c.aux > .002f;
    Vec2 f(std::cos(ang), std::sin(ang));
    float vf0 = dot(vel, f);
    ang += steer * 1.9f * clampf(vf0 / 5.f, -1.f, 1.f) * (hb ? 1.5f : 1.f) * dt;
    f = Vec2(std::cos(ang), std::sin(ang)); Vec2 lat(-f.y, f.x);
    float vf = dot(vel, f), vl = dot(vel, lat);
    if (fuel) vf += (th > 0 ? 10.f : (th < 0 ? -8.f : 0.f)) * dt;
    if (th == 0) vf *= std::exp(-.7f * dt);
    vf *= std::exp(-.12f * dt); if (hb) vf *= std::exp(-2.2f * dt);
    vf = clampf(vf, -6.f, 18.f); vl *= std::exp(-(hb ? 1.1f : 8.f) * dt);
    vel = f * vf + lat * vl;
    float before = vel.len();
    int m = w.moveCircle(pos, vel * dt, .65f);
    if (m & 1) vel.x *= -.25f; if (m & 2) vel.y *= -.25f;
    float lost = before - vel.len();
    if (m && lost > 3.f) { c.hp -= lost * 4; shake += .4f; au.play(Audio::HIT, .9f); }
    pushOut(pos, vel, .65f, car, true);
    float spd = vel.len(); carSpeed = spd;
    for (int i = 0; i < (int)w.ents.size(); i++) {
      Ent& e = w.ents[i]; if (e.dead || !isEnemy(e.k)) continue;
      if (dist(e.pos, pos) < 1.1f && spd > 4.f) { damageEnt(i, spd * 14, vel * .5f); shake += .2f; }
    }
    c.pos = pos; c.vel = vel; c.ang = ang;
    c.aux = std::max(0.f, c.aux - (.00035f * std::fabs(vf) + (th != 0 ? .00025f : .0001f)) * dt);
    noiseT = std::max(noiseT, .5f);
    au.setEngine(fuel ? .35f + .65f * std::fabs(vf) / 18.f : .08f, 38 + std::fabs(vf) * 6);
    if (c.hp <= 0) { Vec2 cp = pos; int id = car; exitCar(); w.kill(id); explode(cp); hurt(40); }
  }

  void psyche(float dt) {
    float threat = 0;
    for (int i : actList) { const Ent& e = w.ents[i]; if (e.alert) { float d = dist(e.pos, pos); if (d < 16) threat = std::max(threat, 1.f - d / 16.f); } }
    bool inside = w.indoor[(int)pos.y * MW + (int)pos.x] != 0, dark = daylight < .35f || (inside && daylight < .7f);
    float ds = 0;
    if (dark) ds -= flashlight ? .15f : .7f;
    else if (threat <= 0) ds += inside ? .25f : .9f;
    ds -= threat * 3.5f;
    sanity = clampf(sanity + ds * dt, 0.f, 100.f);
    if (sanity < 40 && R.f() < dt * .15f) au.play(R.f() < .5f ? Audio::GROAN1 : Audio::GROAN2, .18f);
    phantomT -= dt;
    if (sanity < 35 && phantomT <= 0 && R.f() < dt * .12f) {
      float an = ang + R.r(-.7f, .7f), d = R.r(6, 11); Vec2 p = pos + Vec2(std::cos(an), std::sin(an)) * d;
      if (!w.solid((int)p.x, (int)p.y)) { int id = w.add(K_PHANTOM, p); w.ents[id].tex = S_ZOMB0 + R.i(0, 2); phantomT = 14; }
    }
    if (sanity <= 0) { hp -= 1.5f * dt; hurtT = std::max(hurtT, .1f); if (hp <= 0) { hp = 0; st = ST_DEAD; au.setEngine(0, 40); } }
  }

  void update(float dt) {
    frame++;
    if (st != ST_PLAY || showObj || showInv) { mouseDX = mouseDY = 0; return; }
    clock += dt; gt = START_H + (float)(clock / DAY_LEN) * 24.f;
    sunSin = std::sin((tod() - 6.f) / 24.f * 2 * PI); daylight = clampf(sunSin * 1.6f + .45f, 0, 1); ambient = .08f + .82f * daylight;
    if (gt >= DEADLINE_H && stage < 6) { st = ST_LOSE; au.setEngine(0, 40); return; }
    const Uint8* ks = SDL_GetKeyboardState(nullptr);
    ang -= mouseDX * .0025f; pitch = clampf(pitch - mouseDY * .9f, -120.f, 120.f); mouseDX = mouseDY = 0;
    if (ks[SDL_SCANCODE_LEFT]) ang += 2.2f * dt; if (ks[SDL_SCANCODE_RIGHT]) ang -= 2.2f * dt;
    cd -= dt; recoil = std::max(0.f, recoil - dt * 4); flashT -= dt; hurtT -= dt; swingT -= dt; noiseT -= dt;
    kick *= std::exp(-8 * dt); shake *= std::exp(-6 * dt);
    if (reloadT > 0) { reloadT -= dt; if (reloadT <= 0) finishReload(); }
    Vec2 dir(std::cos(ang), std::sin(ang)), rgt(std::sin(ang), -std::cos(ang));
    if (car >= 0) { drive(dt, ks); jumpReq = false; sprint = false; }
    else {
      float fw = (ks[SDL_SCANCODE_W] || ks[SDL_SCANCODE_UP] ? 1.f : 0.f) - (ks[SDL_SCANCODE_S] || ks[SDL_SCANCODE_DOWN] ? 1.f : 0.f);
      float sd = (ks[SDL_SCANCODE_D] ? 1.f : 0.f) - (ks[SDL_SCANCODE_A] ? 1.f : 0.f);
      bool moving = fw != 0 || sd != 0, shift = ks[SDL_SCANCODE_LSHIFT] || ks[SDL_SCANCODE_RSHIFT];
      sprint = shift && fw > 0 && !winded && stam > 0 && reloadT <= 0;
      if (sprint) { stam -= 22 * dt; stamDelay = .9f; if (stam <= 0) { stam = 0; winded = true; say("OUT OF BREATH"); } }
      else { stamDelay -= dt; if (stamDelay <= 0) stam = std::min(100.f, stam + (moving ? 12.f : 20.f) * dt); if (winded && stam > 30) winded = false; }
      Vec2 wish = dir * fw + rgt * sd; float wl = wish.len(); if (wl > 0) wish = wish * (1.f / wl);
      Vec2 target = wish * (sprint ? 5.4f : 3.0f);
      float acc = z > .01f ? 3.f : 11.f; vel = vel + (target - vel) * std::min(1.f, acc * dt);
      if (jumpReq && z <= .001f && stam > 12) { vz = 3.4f; stam -= 12; stamDelay = .8f; }
      jumpReq = false; vz -= 13 * dt; z += vz * dt; if (z < 0) { z = 0; vz = 0; }
      w.moveCircle(pos, vel * dt, .25f);
      Vec2 v2 = vel; pushOut(pos, v2, .25f, -1, false);
      if (z <= 0 && moving) bob += dt * (sprint ? 12.f : 8.f);
      if (fireHeld && cd <= 0 && reloadT <= 0 && !sprint && (WEAP[cur].autoF || fireLatch)) { tryFire(); if (!WEAP[cur].autoF) fireLatch = false; }
    }
    sprintK = lerpf(sprintK, sprint ? 1.f : 0.f, std::min(1.f, dt * 8));
    updateEnts(dt); updateParts(dt); spawner(dt); psyche(dt);
    // flush deferred drops (adding entities while iterating would invalidate references)
    for (auto& d : drops) w.add(d.k, d.p); drops.clear();
    // story beats
    switch (stage) {
      case 0: if (cans >= 3) { stage = 1; radio("LANTERN: THAT SHOULD BE ENOUGH. BACK TO OUTPOST NINE. KEEP YOUR HEAD DOWN."); } break;
      case 2: if (dist(pos, w.tower) < 8) { stage = 3; radio("LANTERN: I SEE YOU ON THE SCOPE. THE BREAKER IS AT THE TOWER BASE. IT WILL DRAW THEM, WREN. HOLD ON."); } break;
      case 4:
        if (dist(pos, w.tower) < 22) {
          uploadT += dt;
          if (uploadT >= UPLOAD_TIME) { stage = 5; radio("LANTERN: SIGNAL'S OUT. GO. PORT MARROW. DONT STOP FOR ANYTHING."); }
        }
        break;
      case 5: if (dist(pos, w.harbor) < 7) { st = ST_WIN; au.setEngine(0, 40); } break;
    }
    for (auto& m : msgs) m.t -= dt;
    msgs.erase(std::remove_if(msgs.begin(), msgs.end(), [](const Msg& m) { return m.t <= 0; }), msgs.end());
    if (hp < 35 && st == ST_PLAY) { beatT -= dt; if (beatT <= 0) { au.play(Audio::BEAT, .8f); beatT = .6f + hp / 100.f; } }
  }
  bool fireLatch = false;
};

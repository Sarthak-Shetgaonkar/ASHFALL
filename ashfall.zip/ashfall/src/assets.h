#pragma once
#include "common.h"

// All art is generated procedurally at startup: no external files needed.
enum Spr {
  S_ZOMB0, S_ZOMB1, S_ZOMB2, S_RUNNER, S_BRUTE, S_CORPSE, S_HAULER, S_SEDAN, S_WRECK, S_BARREL, S_XBARREL,
  S_TREE, S_LAMP_ON, S_LAMP_OFF, S_RUBBLE, S_AMMO9, S_AMMO12, S_AMMO556, S_HEALTH, S_FUEL, S_NOTE,
  S_WSHOT, S_WRIF, S_RADIO_ON, S_RADIO_OFF, S_SHIP, S_PILLS, S_ARMOR, S_CORPSE_R, S_CORPSE_B, S_COUNT
};
constexpr int SKW = 1024, SKH = 128;

inline Tex genWall(int type) {
  Tex t(64, 64);
  for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
    float n = fbm(x * 0.11f, y * 0.11f, type * 7, 3), g = hrand(x, y, type), r, gc, b;
    switch (type) {
      case 1: {  // ruined brick
        int row = y / 8, off = (row & 1) ? 8 : 0, bx = (x + off) % 16, by = y % 8;
        if (by == 0 || bx == 0) { r = 96; gc = 92; b = 86; }
        else { float br = hrand((x + off) / 16, row, 3); r = 118 + br * 55; gc = 52 + br * 28; b = 42 + br * 16; }
        break; }
      case 2: r = gc = b = 96 + n * 70; b -= 6; break;   // concrete
      case 3: { float rib = (x % 8 < 2) ? 0.7f : 1.f; r = (135 + n * 90) * rib; gc = (62 + n * 45) * rib; b = (34 + n * 22) * rib; break; }  // rust metal
      case 4: { int pl = x / 8; float gr = hrand(pl, y / 12, 9), k = (x % 8 == 0) ? 0.45f : 1.f; r = (108 + gr * 34 + g * 12) * k; gc = (70 + gr * 22 + g * 8) * k; b = (40 + gr * 12) * k; break; }  // planks
      case 5: {  // door
        bool frame = x < 5 || x > 58 || y < 4;
        bool panel = (x > 12 && x < 51 && ((y > 10 && y < 30) || (y > 36 && y < 58)));
        float k = frame ? 0.5f : (panel ? 0.8f : 1.f);
        r = (98 + g * 20) * k; gc = (60 + g * 14) * k; b = (34 + g * 8) * k;
        if (x >= 46 && x <= 50 && y >= 33 && y <= 37) r = gc = b = 170;
        break; }
      default: { float st = 0.8f + 0.3f * (0.5f + 0.5f * std::sin(y * 0.35f + n * 6)); r = (62 + n * 50) * st; gc = (58 + n * 44) * st; b = (54 + n * 40) * st; }  // rock
    }
    float soot = 1.f - 0.45f * fbm(x * 0.05f + 3, y * 0.05f, type + 50, 3) * (0.4f + 0.6f * y / 64.f);
    t.set(x, y, rgb((int)(r * soot), (int)(gc * soot), (int)(b * soot)));
  }
  return t;
}

inline Tex genFloor(int type) {  // 0 dirt 1 ash 2 dead grass 3 road 4 rubble 5 interior
  static const int base[6][3] = {{92,78,62},{78,78,80},{78,82,50},{48,48,52},{104,98,92},{66,56,48}};
  Tex t(64, 64);
  for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
    float n = fbm(x * 0.09f, y * 0.09f, type * 5 + 100, 3), g = hrand(x, y, type + 7);
    float k = 0.7f + 0.55f * n + (g - 0.5f) * 0.2f;
    if (type == 3 && hrand(x / 3, y / 3, 77) < 0.05f) k *= 0.6f;
    if (type == 5 && (x % 16 == 0 || y % 16 == 0)) k *= 0.6f;
    if (type == 4) k *= 0.8f + 0.4f * hrand(x / 8, y / 8, 3);
    t.set(x, y, rgb((int)(base[type][0] * k), (int)(base[type][1] * k), (int)(base[type][2] * k)));
  }
  return t;
}

inline Tex genCeil() {
  Tex t(64, 64);
  for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
    float k = 0.7f + 0.5f * fbm(x * 0.1f, y * 0.1f, 200, 3);
    if (x % 32 < 3 || y % 32 < 3) k *= 0.55f;
    t.set(x, y, rgb((int)(86 * k), (int)(82 * k), (int)(78 * k)));
  }
  return t;
}

inline std::vector<uint8_t> genSky() {
  std::vector<uint8_t> s((size_t)SKW * SKH);
  for (int y = 0; y < SKH; y++) for (int x = 0; x < SKW; x++) {
    float sum = 0, a = 0.5f, norm = 0;
    for (int o = 0; o < 4; o++) {
      sum += a * vnoise(x / (float)SKW * 6 * (1 << o), y / (float)SKH * 2.5f * (1 << o), 300 + o, 6 << o);
      norm += a; a *= 0.5f;
    }
    float v = sum / norm; v = clampf((v - 0.3f) * 2.0f, 0.f, 1.f);
    s[(size_t)y * SKW + x] = (uint8_t)(v * 255);
  }
  return s;
}

inline Tex genZombie(uint32_t skin, uint32_t shirt, uint32_t pants, float b, int seed, bool jaw) {
  Tex t(48, 96); int cx = 24, bw = (int)(11 * b), lw = (int)(8 * b), aw = (int)(5 * b);
  t.rect(cx - lw, 58, cx - 1, 92, pants); t.rect(cx + 1, 58, cx + lw, 92, pants);
  t.rect(cx - lw, 92, cx - 1, 96, rgb(25, 22, 20)); t.rect(cx + 1, 92, cx + lw, 96, rgb(25, 22, 20));
  t.rect(cx - bw, 26, cx + bw, 60, shirt);
  t.rect(cx - bw - aw, 28, cx - bw, 64, shirt); t.rect(cx + bw, 28, cx + bw + aw, 64, shirt);
  t.rect(cx - bw - aw, 64, cx - bw, 77, skin); t.rect(cx + bw, 64, cx + bw + aw, 77, skin);
  t.ellipse((float)cx, 15, 7 * std::sqrt(b) + 1, 10, skin);
  t.rect(cx - 5, 12, cx - 2, 15, glowc(255, 210, 60)); t.rect(cx + 2, 12, cx + 5, 15, glowc(255, 210, 60));
  if (jaw) t.rect(cx - 4, 19, cx + 4, 27, rgb(60, 8, 8)); else t.rect(cx - 4, 20, cx + 4, 23, rgb(30, 10, 10));
  for (int i = 0; i < 60; i++) {
    int x = cx - bw - aw + (int)(hrand(i, 1, seed) * 2 * (bw + aw)), y = 26 + (int)(hrand(i, 2, seed) * 56);
    if (hrand(i, 3, seed) < 0.5f && (t.get(x, y) >> 24)) t.rect(x, y, x + 2, y + 2, rgb(120, 18, 18));
  }
  for (int x = cx - bw; x < cx + bw; x++) if (hrand(x, 9, seed) < 0.3f) t.rect(x, 55 + (int)(hrand(x, 4, seed) * 4), x + 1, 60, 0);
  t.grunge(0.35f, seed);
  return t;
}

inline Tex genCorpse() {
  Tex t(64, 20);
  t.ellipse(32, 16, 28, 3, rgb(70, 8, 8));
  t.rect(4, 7, 46, 16, rgb(78, 80, 66)); t.rect(44, 8, 62, 15, rgb(46, 44, 50));
  t.ellipse(8, 11, 6, 6, rgb(138, 148, 128));
  t.grunge(0.35f, 12);
  return t;
}

inline Tex genCar(uint32_t body, int kind) {  // 0 hauler pickup, 1 sedan, 2 wreck
  Tex t(128, 64); uint32_t dark = rgb(18, 18, 20), glass = rgb(35, 45, 52);
  uint32_t b = kind == 2 ? rgb(52, 42, 36) : body;
  t.rect(10, 46, 30, 64, dark); t.rect(98, 46, 118, 64, dark);
  t.rect(6, 26, 122, 52, b);
  if (kind == 0) { t.rect(22, 4, 106, 28, b); t.rect(28, 9, 100, 26, glass); t.rect(62, 9, 66, 26, b); t.rect(6, 22, 22, 27, rgb(60, 50, 30)); }
  else { t.rect(24, 8, 104, 28, b); t.rect(30, 12, 98, 27, kind == 2 ? 0 : glass); }
  t.rect(4, 48, 124, 54, rgb(55, 55, 58));
  if (kind != 2) { t.rect(10, 32, 22, 38, glowc(255, 40, 30)); t.rect(106, 32, 118, 38, glowc(255, 40, 30)); }
  t.rect(54, 40, 74, 48, rgb(190, 190, 180));
  t.grunge(0.4f, kind + 30);
  return t;
}

inline Tex genBarrel(bool expl) {
  Tex t(32, 44); uint32_t c = expl ? rgb(168, 40, 28) : rgb(72, 84, 90);
  t.rect(4, 4, 28, 42, c); t.ellipse(16, 5, 12, 4, expl ? rgb(190, 60, 40) : rgb(96, 108, 112));
  t.rect(4, 12, 28, 14, rgb(30, 30, 30)); t.rect(4, 30, 28, 32, rgb(30, 30, 30));
  if (expl) { t.rect(10, 17, 22, 27, rgb(232, 200, 40)); t.rect(15, 18, 17, 23, rgb(20, 20, 20)); t.rect(15, 24, 17, 26, rgb(20, 20, 20)); }
  t.grunge(0.4f, expl ? 41 : 42);
  return t;
}

inline void branch(Tex& t, float x, float y, float a, float len, float th, int d, int seed) {
  if (d == 0 || len < 3) return;
  float x2 = x + std::cos(a) * len, y2 = y + std::sin(a) * len;
  t.line(x, y, x2, y2, th, rgb(46 + (seed % 5) * 2, 38, 34));
  float s1 = hrand(d, seed, 1) * 0.5f + 0.35f, s2 = hrand(d, seed, 2) * 0.5f + 0.35f;
  branch(t, x2, y2, a - s1, len * 0.72f, th * 0.68f, d - 1, seed * 3 + 1);
  branch(t, x2, y2, a + s2, len * 0.72f, th * 0.68f, d - 1, seed * 3 + 2);
  if (d > 3 && hrand(d, seed, 5) < 0.6f) branch(t, (x + x2) / 2, (y + y2) / 2, a + (hrand(d, seed, 6) - .5f) * 2.2f, len * 0.5f, th * 0.5f, d - 2, seed * 5 + 3);
}
inline Tex genTree() { Tex t(64, 128); branch(t, 32, 127, -PI / 2, 46, 6, 5, 7); return t; }

inline Tex genLamp(bool on) {
  Tex t(16, 96);
  t.rect(7, 12, 9, 96, rgb(70, 70, 74)); t.rect(3, 10, 9, 12, rgb(70, 70, 74)); t.rect(1, 9, 6, 14, rgb(40, 40, 44));
  if (on) t.ellipse(3.5f, 16, 4.5f, 4.5f, glowc(255, 200, 120)); else t.ellipse(3.5f, 16, 3, 3, rgb(60, 56, 50));
  return t;
}

inline Tex genRubble() {
  Tex t(64, 28); RNG r(5);
  for (int i = 0; i < 26; i++) {
    int w = r.i(6, 16), h = r.i(4, 12), x = r.i(0, 64 - w), y = r.i(10, 28 - h) + (i > 12 ? 4 : 0); if (y + h > 28) y = 28 - h;
    int g = r.i(60, 120); t.rect(x, y, x + w, y + h, rgb(g, g - 4, g - 8));
  }
  t.grunge(0.3f, 77);
  return t;
}

inline Tex genPickup(int kind) {  // 0 9mm, 1 12ga, 2 556, 3 health, 4 fuel, 5 note
  Tex t(24, 24);
  switch (kind) {
    case 0: t.rect(2, 10, 22, 22, rgb(70, 82, 46)); for (int i = 0; i < 6; i++) t.rect(3 + i * 3, 5, 5 + i * 3, 10, rgb(200, 160, 60)); t.rect(4, 14, 20, 17, rgb(210, 190, 90)); break;
    case 1: for (int i = 0; i < 3; i++) { t.rect(3 + i * 7, 5, 8 + i * 7, 18, rgb(170, 30, 24)); t.rect(3 + i * 7, 17, 8 + i * 7, 22, rgb(200, 160, 60)); } break;
    case 2: t.rect(2, 9, 22, 22, rgb(48, 60, 44)); for (int i = 0; i < 3; i++) t.rect(4 + i * 6, 4, 8 + i * 6, 9, rgb(190, 150, 60)); t.rect(4, 14, 20, 17, rgb(200, 200, 170)); break;
    case 3: t.rect(3, 6, 21, 22, rgb(222, 222, 216)); t.rect(10, 8, 14, 20, rgb(190, 20, 20)); t.rect(6, 12, 18, 16, rgb(190, 20, 20)); break;
    case 4: t.rect(4, 6, 20, 22, rgb(168, 34, 24)); t.rect(14, 3, 19, 6, rgb(230, 190, 40)); t.rect(6, 3, 12, 6, rgb(110, 20, 16)); t.rect(8, 11, 16, 13, rgb(100, 18, 14)); break;
    case 6: t.rect(7, 8, 17, 22, rgb(60, 100, 170)); t.rect(8, 4, 16, 8, rgb(230, 230, 225)); t.rect(8, 12, 16, 18, rgb(225, 225, 220)); break;
    case 7: t.rect(4, 4, 20, 22, rgb(58, 66, 84)); t.rect(4, 4, 7, 10, rgb(40, 46, 60)); t.rect(17, 4, 20, 10, rgb(40, 46, 60)); t.rect(8, 11, 16, 19, rgb(88, 98, 118)); break;
    default: t.rect(5, 3, 19, 21, rgb(212, 202, 160)); for (int i = 0; i < 5; i++) t.rect(7, 6 + i * 3, 17, 7 + i * 3, rgb(90, 80, 60)); break;
  }
  t.grunge(0.25f, 90 + kind);
  return t;
}

inline Tex genLongGun(bool rifle) {
  Tex t(40, 16);
  t.rect(2, 6, 28, 9, rgb(30, 30, 36));
  t.rect(26, 4, 38, 12, rifle ? rgb(40, 44, 36) : rgb(112, 64, 34));
  t.rect(12, 8, 18, 11, rifle ? rgb(30, 30, 30) : rgb(100, 56, 30));
  return t;
}

inline Tex genRadio(bool on) {
  Tex t(40, 200); uint32_t steel = rgb(64, 66, 70);
  auto lx = [](float y) { return lerpf(6, 18, (199 - y) / 185.f); };
  auto rx = [](float y) { return lerpf(34, 22, (199 - y) / 185.f); };
  t.line(6, 199, 18, 14, 2, steel); t.line(34, 199, 22, 14, 2, steel); t.rect(19, 4, 21, 16, steel);
  for (float y = 199; y > 40; y -= 22) {
    float y2 = y - 22;
    t.line(lx(y), y, rx(y2), y2, 1.2f, steel); t.line(rx(y), y, lx(y2), y2, 1.2f, steel); t.line(lx(y2), y2, rx(y2), y2, 1.4f, steel);
  }
  t.ellipse(20, 3, 3, 3, on ? glowc(255, 30, 20) : rgb(80, 10, 10));
  t.grunge(0.3f, 66);
  return t;
}

inline Tex genShip() {
  Tex t(256, 80);
  t.rect(8, 48, 244, 72, rgb(24, 30, 44)); t.trap(48, 72, 6, 12, 14, 28, rgb(24, 30, 44));
  t.rect(8, 60, 244, 64, rgb(140, 30, 28));
  t.rect(150, 22, 230, 48, rgb(60, 66, 76)); t.rect(180, 8, 224, 22, rgb(70, 76, 86)); t.rect(120, 14, 140, 48, rgb(120, 40, 30));
  for (int x = 156; x < 228; x += 8) t.rect(x, 30, x + 4, 34, glowc(255, 210, 120));
  for (int x = 184; x < 222; x += 8) t.rect(x, 12, x + 4, 16, glowc(255, 230, 150));
  for (int x = 20; x < 140; x += 12) t.rect(x, 44, x + 4, 47, glowc(255, 190, 90));
  t.ellipse(240, 12, 3, 3, glowc(255, 255, 230)); t.rect(238, 12, 240, 48, rgb(50, 50, 56));
  t.grunge(0.25f, 55);
  return t;
}

// ----- first person weapon sprites (drawn 2x) -----
inline Tex genPistol() {
  Tex t(64, 80); uint32_t glove = rgb(58, 46, 40);
  t.trap(44, 80, 32, 22, 32, 26, rgb(28, 28, 31));
  t.trap(6, 48, 32, 12, 32, 20, rgb(46, 48, 54));
  t.rect(30, 6, 34, 44, rgb(68, 70, 78));
  for (int y = 34; y < 44; y += 2) { t.rect(24, y, 26, y + 1, rgb(20, 20, 22)); t.rect(38, y, 40, y + 1, rgb(20, 20, 22)); }
  t.rect(31, 0, 33, 7, rgb(220, 220, 205)); t.rect(25, 38, 28, 42, rgb(12, 12, 12)); t.rect(36, 38, 39, 42, rgb(12, 12, 12));
  t.trap(54, 80, 45, 14, 48, 16, glove); t.trap(56, 80, 17, 12, 15, 14, glove);
  t.grunge(0.2f, 5);
  return t;
}
inline Tex genShotgun() {
  Tex t(96, 100); uint32_t glove = rgb(58, 46, 40);
  t.trap(0, 64, 48, 10, 48, 28, rgb(22, 24, 30));
  t.rect(47, 0, 49, 64, rgb(84, 86, 96)); t.rect(46, 0, 50, 3, rgb(240, 230, 180));
  t.trap(40, 78, 48, 26, 48, 36, rgb(112, 64, 34));
  for (int y = 42; y < 78; y += 3) t.rect(36 + (y % 7), y, 40 + (y % 7), y + 1, rgb(80, 44, 24));
  t.trap(76, 100, 48, 36, 48, 42, rgb(28, 28, 32));
  t.trap(50, 80, 22, 14, 18, 16, glove); t.trap(56, 100, 76, 14, 80, 16, glove);
  t.grunge(0.2f, 6);
  return t;
}
inline Tex genCarbine() {
  Tex t(96, 100); uint32_t glove = rgb(58, 46, 40);
  t.trap(0, 50, 48, 3, 48, 8, rgb(22, 24, 26)); t.rect(47, 0, 49, 14, rgb(14, 14, 14));
  t.trap(36, 72, 48, 16, 48, 24, rgb(54, 58, 46));
  t.trap(66, 100, 48, 24, 48, 30, rgb(30, 32, 34));
  t.rect(40, 58, 44, 68, rgb(14, 14, 14)); t.rect(52, 58, 56, 68, rgb(14, 14, 14));
  t.trap(52, 80, 28, 14, 26, 16, glove); t.trap(60, 100, 70, 14, 72, 16, glove);
  t.grunge(0.2f, 7);
  return t;
}
inline Tex genCrowbar() {
  Tex t(24, 90);
  t.line(12, 88, 12, 10, 5, rgb(120, 28, 24)); t.line(12, 10, 5, 4, 4, rgb(120, 28, 24)); t.rect(8, 70, 17, 90, rgb(58, 46, 40));
  t.grunge(0.2f, 8);
  return t;
}

// Fungal-infected "Bloomed": blind, hunched, with a fan of fungal plates around a screaming open mouth.
// stage 0 = fully bloomed, 1 = early growth (fast runner), 2 = armoured brute
inline Tex genBloomed(int stage, float b, int seed) {
  Tex t(64, 96); int cx = 32;
  uint32_t flesh = rgb(178, 152, 142), fleshD = rgb(116, 88, 82), wound = rgb(168, 64, 64), vest = rgb(118, 120, 114),
           pants = rgb(46, 42, 40), fung = rgb(208, 140, 50), fungD = rgb(138, 82, 26), fungL = rgb(238, 192, 98);
  auto cluster = [&](float x, float y, float r) {
    for (int k = 0; k < 5; k++) {
      float a = hrand(k, (int)x, seed) * 6.28f, d = r * 0.6f * hrand(k, (int)y, seed + 1);
      t.ellipse(x + std::cos(a) * d, y + std::sin(a) * d, r * 0.55f, r * 0.4f, (k & 1) ? fung : fungD);
    }
    t.ellipse(x, y - r * 0.2f, r * 0.5f, r * 0.35f, fungL);
    t.set((int)x, (int)(y - r * 0.3f), glowc(255, 190, 90));  // faint bioluminescent spore
  };
  int lw = (int)(6 * b);
  t.rect(cx - lw - 4, 62, cx - 1, 90, pants); t.rect(cx + 1, 64, cx + lw + 4, 92, pants);
  t.rect(cx - lw - 5, 90, cx, 96, rgb(30, 26, 24)); t.rect(cx, 92, cx + lw + 5, 96, rgb(30, 26, 24));
  float tw = 13 * b;
  t.ellipse(cx + 2, 46, tw, 19, flesh);
  for (int i = 0; i < 4; i++) t.line(cx + 2 - tw + 5, 34 + i * 4, cx + 2 + tw - 5, 36 + i * 4, 1.2f, fleshD);
  t.ellipse(cx + 2, 56, tw - 1, 11, vest);
  for (int i = 0; i < 6; i++) t.ellipse(cx + 2 + (hrand(i, 1, seed) - .5f) * 2 * (tw - 4), 34 + hrand(i, 2, seed) * 28, 2.5f, 3.2f, wound);
  float ax = tw * 0.9f;
  t.line(cx + 2 - ax, 34, cx - ax - 8 * b, 58, 5 * b, flesh); t.line(cx - ax - 8 * b, 58, cx - ax - 3, 80, 4 * b, flesh);
  t.line(cx + 2 + ax, 34, cx + ax + 9 * b, 56, 5 * b, flesh); t.line(cx + ax + 9 * b, 56, cx + ax + 5, 78, 4 * b, flesh);
  t.line(cx - ax - 3, 80, cx - ax - 6, 88, 2, fleshD); t.line(cx + ax + 5, 78, cx + ax + 8, 86, 2, fleshD);
  cluster(cx + 2 - ax, 32, 6 * b); cluster(cx + 2 + ax, 33, 5.5f * b); cluster(cx - ax - 8 * b, 56, 4);
  if (stage != 1) { cluster((float)cx + 6, 44, 5); cluster((float)cx - 6, 60, 4.5f); }
  if (stage == 2) { cluster((float)cx - 8, 40, 7); cluster((float)cx + 10, 52, 6.5f); cluster((float)cx, 30, 8); }
  float hx = cx + 3.f, hy = 17.f; int nb = stage == 1 ? 4 : 9;
  for (int k = 0; k < nb; k++) {  // fan of fungal plates around the skull
    float a = stage == 1 ? PI * (1.05f + 0.5f * k / (float)(nb - 1)) : PI + PI * k / (float)(nb - 1);
    float px = hx + std::cos(a) * 9, py = hy + std::sin(a) * 9;
    t.ellipse(px, py, 8.5f * (stage == 2 ? 1.2f : 1.f) * (0.8f + 0.4f * hrand(k, 3, seed)), 6.5f, (k & 1) ? fung : fungD);
    t.line(hx, hy, px + std::cos(a) * 5, py + std::sin(a) * 5, 1, fungL);
    t.set((int)(px + std::cos(a) * 6), (int)(py + std::sin(a) * 6), glowc(255, 190, 90));
  }
  t.ellipse(hx, hy + 2, 7, 9, flesh);
  t.ellipse(hx, hy + 6, 4.5f, 7.5f, rgb(92, 14, 20));
  t.rect((int)hx - 3, (int)hy, (int)hx + 4, (int)hy + 2, rgb(225, 220, 205));
  t.rect((int)hx - 3, (int)hy + 11, (int)hx + 4, (int)hy + 13, rgb(225, 220, 205));
  t.ellipse(hx, hy + 8, 2.5f, 3.f, wound);
  t.grunge(0.3f, seed);
  return t;
}

// Dead Bloomed: lying in a blood pool with the fungal bloom still spreading across the body.
inline Tex genBloomedCorpse(int stage, float b, int seed) {
  Tex t(96, 28);
  uint32_t flesh = rgb(172, 146, 136), fleshD = rgb(112, 86, 80), wound = rgb(150, 52, 52), vest = rgb(112, 114, 108),
           pants = rgb(44, 40, 38), fung = rgb(200, 134, 48), fungD = rgb(132, 78, 24), fungL = rgb(232, 186, 94);
  auto cluster = [&](float x, float y, float r) {
    for (int k = 0; k < 5; k++) {
      float a = hrand(k, (int)x, seed) * 6.28f, d = r * 0.6f * hrand(k, (int)y, seed + 1);
      t.ellipse(x + std::cos(a) * d, y + std::sin(a) * d, r * 0.6f, r * 0.4f, (k & 1) ? fung : fungD);
    }
    t.ellipse(x, y - r * 0.2f, r * 0.5f, r * 0.35f, fungL);
    t.set((int)x, (int)(y - r * 0.3f), glowc(255, 190, 90));
  };
  t.ellipse(50, 24, 44, 4, rgb(66, 8, 10)); t.ellipse(28, 25, 22, 3, rgb(94, 12, 14));
  t.rect(60, 13, 92, 19, pants); t.rect(62, 19, 90, 24, pants);
  t.rect(90, 13, 95, 19, rgb(28, 24, 22)); t.rect(88, 19, 94, 24, rgb(28, 24, 22));
  t.ellipse(44, 17, 19 * b, 8 * std::min(b, 1.2f), flesh);
  t.ellipse(46, 18, 19 * b - 2, 5.5f, vest);
  for (int i = 0; i < 4; i++) t.line(30 + i * 4, 11, 32 + i * 4, 14, 1.2f, fleshD);
  for (int i = 0; i < 4; i++) t.ellipse(32 + hrand(i, 1, seed) * 26, 13 + hrand(i, 2, seed) * 8, 2.2f, 2.6f, wound);
  t.line(34, 12, 18, 22, 4, flesh); t.line(18, 22, 8, 25, 3, flesh); t.line(40, 22, 26, 26, 3, flesh);
  cluster(34, 10, 5 * b); cluster(54, 11, 4.5f * b); cluster(44, 13, 5);
  if (stage == 2) { cluster(40, 9, 7); cluster(60, 14, 6); }
  float hx = 14, hy = 13; int nb = stage == 1 ? 4 : 8;
  for (int k = 0; k < nb; k++) {
    float a = PI * (1.f + k / (float)(nb - 1)), px = hx + std::cos(a) * 7, py = hy + 1 + std::sin(a) * 7;
    t.ellipse(px, py, 6, 4.5f, (k & 1) ? fung : fungD);
    t.set((int)(px + std::cos(a) * 4), (int)(py + std::sin(a) * 4), glowc(255, 190, 90));
  }
  t.ellipse(hx + 1, hy + 2, 5.5f, 6, flesh); t.ellipse(hx - 1, hy + 3, 3.2f, 4.5f, rgb(92, 14, 20));
  t.rect((int)hx - 3, (int)hy + 1, (int)hx + 1, (int)hy + 2, rgb(225, 220, 205));
  t.grunge(0.3f, seed);
  return t;
}

struct Assets {
  Tex wall[9], floor[6], ceil, spr[S_COUNT], wpn[4];
  std::vector<uint8_t> sky;
  void init() {
    for (int i = 1; i <= 8; i++) if (i != 6) wall[i] = genWall(i);
    for (int i = 0; i < 6; i++) floor[i] = genFloor(i);
    ceil = genCeil(); sky = genSky();
    spr[S_ZOMB0] = genBloomed(0, 1.0f, 11); spr[S_ZOMB1] = genBloomed(0, 1.08f, 12); spr[S_ZOMB2] = genBloomed(0, 0.95f, 13);
    spr[S_RUNNER] = genBloomed(1, 0.85f, 14); spr[S_BRUTE] = genBloomed(2, 1.35f, 15);
    spr[S_CORPSE] = genBloomedCorpse(0, 1.0f, 21); spr[S_CORPSE_R] = genBloomedCorpse(1, 0.85f, 22); spr[S_CORPSE_B] = genBloomedCorpse(2, 1.35f, 23);
    spr[S_HAULER] = genCar(rgb(62, 86, 60), 0); spr[S_SEDAN] = genCar(rgb(120, 110, 96), 1); spr[S_WRECK] = genCar(0, 2);
    spr[S_BARREL] = genBarrel(false); spr[S_XBARREL] = genBarrel(true);
    spr[S_TREE] = genTree(); spr[S_LAMP_ON] = genLamp(true); spr[S_LAMP_OFF] = genLamp(false); spr[S_RUBBLE] = genRubble();
    spr[S_AMMO9] = genPickup(0); spr[S_AMMO12] = genPickup(1); spr[S_AMMO556] = genPickup(2);
    spr[S_HEALTH] = genPickup(3); spr[S_FUEL] = genPickup(4); spr[S_NOTE] = genPickup(5);
    spr[S_WSHOT] = genLongGun(false); spr[S_WRIF] = genLongGun(true);
    spr[S_RADIO_ON] = genRadio(true); spr[S_RADIO_OFF] = genRadio(false); spr[S_SHIP] = genShip();
    spr[S_PILLS] = genPickup(6); spr[S_ARMOR] = genPickup(7);
    wpn[0] = genPistol(); wpn[1] = genShotgun(); wpn[2] = genCarbine(); wpn[3] = genCrowbar();
  }
};
inline Assets A;

#pragma once
#include "assets.h"

enum Kind : uint8_t {
  K_ZOMBIE, K_RUNNER, K_BRUTE, K_CORPSE, K_CAR, K_BARREL, K_XBARREL, K_TREE, K_LAMP, K_RUBBLE,
  K_AMMO9, K_AMMO12, K_AMMO556, K_HEALTH, K_FUEL, K_NOTE, K_WSHOT, K_WRIF, K_PILLS, K_ARMOR, K_RADIO, K_SHIP, K_PHANTOM
};
inline bool isEnemy(int k) { return k <= K_BRUTE; }
inline bool isPickup(int k) { return k >= K_AMMO9 && k <= K_ARMOR; }
inline bool isSolidKind(int k) { return k == K_CAR || k == K_BARREL || k == K_XBARREL || k == K_TREE || k == K_LAMP || k == K_RADIO; }

constexpr int NLORE = 12;
inline const char* LORE[NLORE] = {
  "NOTE: DAY 4. THE BLOOM RIDES THE DUST. WE TAPED THE WINDOWS. IT DID NOT HELP.",
  "NOTE: THEY HUNT BY SOUND. WALK. IF YOU MUST RUN, RUN FAR. DONT FIRE UNLESS YOU HAVE TO.",
  "NOTE: THE LAMPS STILL BURN ON THE OLD ROAD. THEY GATHER UNDER THEM AND JUST WATCH.",
  "NOTE: MARROW FERRY ROSTER. 212 BOARDED. 40 LEFT BEHIND. I AM ONE OF THE 40.",
  "NOTE: THE BIG ONES WEAR HI-VIS VESTS. THEY WERE THE FOREMEN. THEY STILL KNOW THE SHIFT.",
  "NOTE: A DOOR WILL HOLD THEM. THEY CANNOT WORK A HANDLE. CLOSE IT BEHIND YOU.",
  "NOTE: WE LOST DUNMERE IN ONE NIGHT. THE SIRENS ONLY MADE IT WORSE.",
  "NOTE: THE RELAY KEEPS BROADCASTING. SOMEONE MUST STILL BE UP THERE. I HOPE.",
  "NOTE: DAY 9. MY SON ASKED WHY THE SKY IS ALWAYS THE COLOR OF A WOUND.",
  "NOTE: FUEL IS GOLD NOW. CHECK THE GARAGES. CHECK THE CHURCH CELLARS.",
  "NOTE: DONT TRUST THE QUIET. THE QUIET MEANS THEY ARE LISTENING.",
  "ODA'S LOG: LANTERN IS ME. ODA. I STAY ON THE RELAY SO THE SHIP CAN FIND YOU."};

struct Ent {
  Kind k = K_TREE; Vec2 pos, vel;
  float ang = 0, hp = 1, r = 0, z = 0, scale = 1, t = 0, hit = 0, atk = 0, aux = 0, aux2 = 0;
  int tex = 0;
  bool dead = false, active = false, alert = false, wreck = false, dyn = false, hauler = false;
};

inline Ent makeEnt(Kind k, Vec2 p, RNG& R) {
  Ent e; e.k = k; e.pos = p; e.t = R.f() * 10;
  switch (k) {
    case K_ZOMBIE: e.hp = 60; e.r = .28f; e.scale = .95f; e.tex = S_ZOMB0 + R.i(0, 2); break;
    case K_RUNNER: e.hp = 35; e.r = .25f; e.scale = .9f; e.tex = S_RUNNER; break;
    case K_BRUTE: e.hp = 300; e.r = .45f; e.scale = 1.3f; e.tex = S_BRUTE; break;
    case K_CORPSE: e.scale = .22f; e.tex = S_CORPSE; break;
    case K_CAR: e.hp = 200; e.r = .8f; e.scale = .55f; e.tex = S_SEDAN; e.aux = R.r(.25f, .7f); break;
    case K_BARREL: e.hp = 40; e.r = .28f; e.scale = .42f; e.tex = S_BARREL; break;
    case K_XBARREL: e.hp = 25; e.r = .28f; e.scale = .42f; e.tex = S_XBARREL; break;
    case K_TREE: e.r = .18f; e.scale = 1.8f; e.tex = S_TREE; break;
    case K_LAMP: e.r = .12f; e.scale = 1.2f; e.tex = S_LAMP_ON; break;
    case K_RUBBLE: e.scale = .3f; e.tex = S_RUBBLE; break;
    case K_AMMO9: e.scale = .16f; e.tex = S_AMMO9; break;
    case K_AMMO12: e.scale = .16f; e.tex = S_AMMO12; break;
    case K_AMMO556: e.scale = .16f; e.tex = S_AMMO556; break;
    case K_HEALTH: e.scale = .16f; e.tex = S_HEALTH; break;
    case K_FUEL: e.scale = .2f; e.tex = S_FUEL; break;
    case K_NOTE: e.scale = .16f; e.tex = S_NOTE; break;
    case K_WSHOT: e.scale = .14f; e.tex = S_WSHOT; break;
    case K_WRIF: e.scale = .14f; e.tex = S_WRIF; break;
    case K_PILLS: e.scale = .14f; e.tex = S_PILLS; break;
    case K_ARMOR: e.scale = .3f; e.tex = S_ARMOR; break;
    case K_PHANTOM: e.scale = .95f; e.tex = S_ZOMB0; break;
    case K_RADIO: e.r = 1.1f; e.scale = 7.f; e.tex = S_RADIO_ON; break;
    case K_SHIP: e.scale = 3.4f; e.tex = S_SHIP; break;
  }
  return e;
}

struct World {
  std::vector<uint8_t> cell, ground, indoor;  // cell: 0 empty,1-4 walls,5 door,6 open door,8 cliff
  std::vector<Ent> ents; std::vector<int> freeSlots;
  Vec2 start{512.5f, 510.5f}, tower{905.5f, 140.5f}, harbor{110.5f, 905.5f};
  int haulerIdx = -1, noteCtr = 0; RNG R{1};

  bool in(int x, int y) const { return x >= 0 && y >= 0 && x < MW && y < MH; }
  int cellAt(int x, int y) const { return in(x, y) ? cell[y * MW + x] : 8; }
  bool solid(int x, int y) const { int c = cellAt(x, y); return c != 0 && c != 6; }
  int add(Kind k, Vec2 p) {
    Ent e = makeEnt(k, p, R);
    if (!freeSlots.empty()) { int i = freeSlots.back(); freeSlots.pop_back(); ents[i] = e; return i; }
    ents.push_back(e); return (int)ents.size() - 1;
  }
  void kill(int i) { if (!ents[i].dead) { ents[i].dead = true; freeSlots.push_back(i); } }

  bool blockedCircle(Vec2 p, float r) const {
    int x0 = (int)std::floor(p.x - r), x1 = (int)std::floor(p.x + r), y0 = (int)std::floor(p.y - r), y1 = (int)std::floor(p.y + r);
    for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) if (solid(x, y)) {
      float cx = clampf(p.x, (float)x, x + 1.f), cy = clampf(p.y, (float)y, y + 1.f), dx = p.x - cx, dy = p.y - cy;
      if (dx * dx + dy * dy < r * r) return true;
    }
    return false;
  }
  // slide-move; returns bitmask of blocked axes (1 = x, 2 = y)
  int moveCircle(Vec2& p, Vec2 d, float r) const {
    int mask = 0; int n = (int)(d.len() / 0.25f) + 1; Vec2 s = d * (1.f / n);
    for (int i = 0; i < n; i++) {
      Vec2 q(p.x + s.x, p.y);
      if (!blockedCircle(q, r)) p = q; else mask |= 1;
      q = Vec2(p.x, p.y + s.y);
      if (!blockedCircle(q, r)) p = q; else mask |= 2;
    }
    return mask;
  }

  // ---------- generation ----------
  bool roomFree(int x0, int y0, int w, int h) const {
    for (int y = y0; y < y0 + h; y++) for (int x = x0; x < x0 + w; x++) {
      if (x < 6 || y < 6 || x >= MW - 6 || y >= MH - 6) return false;
      if (cell[y * MW + x] || ground[y * MW + x] == 3) return false;
    }
    return true;
  }
  Vec2 randFree(Vec2 c, float rad) {
    for (int a = 0; a < 60; a++) {
      Vec2 p(c.x + R.r(-rad, rad), c.y + R.r(-rad, rad)); int x = (int)p.x, y = (int)p.y;
      if (in(x, y) && !cell[y * MW + x] && ground[y * MW + x] != 5) return p;
    }
    return c;
  }
  Vec2 randIndoor(Vec2 c, float rad) {
    for (int a = 0; a < 400; a++) {
      Vec2 p(c.x + R.r(-rad, rad), c.y + R.r(-rad, rad)); int x = (int)p.x, y = (int)p.y;
      if (in(x, y) && !cell[y * MW + x] && ground[y * MW + x] == 5) return p;
    }
    return randFree(c, rad);
  }
  Vec2 randIn(int x0, int y0, int w, int h) {
    for (int a = 0; a < 30; a++) {
      int x = x0 + 1 + R.i(0, w - 3), y = y0 + 1 + R.i(0, h - 3);
      if (!cell[y * MW + x]) return Vec2(x + .2f + .6f * R.f(), y + .2f + .6f * R.f());
    }
    return Vec2(x0 + w / 2.f, y0 + h / 2.f);
  }
  Kind pickLoot() {
    float f = R.f();
    return f < .25f ? K_AMMO9 : f < .40f ? K_AMMO12 : f < .48f ? K_AMMO556 : f < .66f ? K_HEALTH : f < .78f ? K_FUEL : f < .90f ? K_PILLS : K_ARMOR;
  }

  void room(int x0, int y0, int w, int h, int tex, int side, bool closed, bool ruin) {
    for (int y = y0; y < y0 + h; y++) for (int x = x0; x < x0 + w; x++) {
      bool edge = (x == x0 || x == x0 + w - 1 || y == y0 || y == y0 + h - 1); int i = y * MW + x;
      indoor[i] = 1;
      if (edge) cell[i] = (uint8_t)tex; else { cell[i] = 0; ground[i] = 5; }  // walls always get built, even over roads
    }
    int dx, dy;
    switch (side) {
      case 0: dx = x0 + w / 2; dy = y0; break;
      case 1: dx = x0 + w / 2; dy = y0 + h - 1; break;
      case 2: dx = x0; dy = y0 + h / 2; break;
      default: dx = x0 + w - 1; dy = y0 + h / 2; break;
    }
    cell[dy * MW + dx] = closed ? 5 : 0;
    if (ruin) for (int y = y0; y < y0 + h; y++) for (int x = x0; x < x0 + w; x++) {
      bool edge = (x == x0 || x == x0 + w - 1 || y == y0 || y == y0 + h - 1);
      bool corner = (x == x0 || x == x0 + w - 1) && (y == y0 || y == y0 + h - 1);
      if (edge && !corner && !(x == dx && y == dy) && R.f() < .10f) cell[y * MW + x] = 0;
    }
    if (w >= 9 && R.f() < .55f) {
      int px = x0 + w / 2 + 2, gy = y0 + 1 + R.i(0, h - 3);
      if (px < x0 + w - 1) for (int y = y0 + 1; y < y0 + h - 1; y++) cell[y * MW + px] = (y == gy) ? 0 : 2;
    }
  }
  void furnish(int x0, int y0, int w, int h) {
    int n = R.i(1, 3);
    for (int i = 0; i < n; i++) add(pickLoot(), randIn(x0, y0, w, h));
    if (R.f() < .4f) add(R.f() < .4f ? K_XBARREL : K_BARREL, randIn(x0, y0, w, h));
    if (R.f() < .5f) { int zn = R.i(1, 3); for (int i = 0; i < zn; i++) add(R.f() < .2f ? K_RUNNER : K_ZOMBIE, randIn(x0, y0, w, h)); }
    if (R.f() < .2f) { int id = add(K_NOTE, randIn(x0, y0, w, h)); ents[id].aux = (float)(noteCtr++ % (NLORE - 1)); }
  }
  void buildTown(Vec2 c) {
    static const int texs[4] = {1, 1, 2, 4};
    int nb = R.i(4, 8), built = 0;
    for (int a = 0; a < 70 && built < nb; a++) {
      int bw = R.i(6, 12), bh = R.i(6, 10);
      int x0 = (int)c.x + R.i(-20, 20) - bw / 2, y0 = (int)c.y + R.i(-20, 20) - bh / 2;
      if (!roomFree(x0 - 2, y0 - 2, bw + 4, bh + 4)) continue;
      Vec2 bc(x0 + bw / 2.f, y0 + bh / 2.f), dd = c - bc;
      int side = std::fabs(dd.x) > std::fabs(dd.y) ? (dd.x > 0 ? 3 : 2) : (dd.y > 0 ? 1 : 0);
      room(x0, y0, bw, bh, texs[R.i(0, 3)], side, R.f() < .6f, true);
      furnish(x0, y0, bw, bh); built++;
    }
    int nl = R.i(2, 4); for (int i = 0; i < nl; i++) add(K_LAMP, randFree(c, 22));
    int nw = R.i(1, 3); for (int i = 0; i < nw; i++) { int id = add(K_CAR, randFree(c, 22)); ents[id].wreck = R.f() < .7f; ents[id].tex = ents[id].wreck ? S_WRECK : S_SEDAN; if (ents[id].wreck) ents[id].aux = 0; }
    int nb2 = R.i(2, 4); for (int i = 0; i < nb2; i++) add(R.f() < .25f ? K_XBARREL : K_BARREL, randFree(c, 22));
    int nr = R.i(3, 6); for (int i = 0; i < nr; i++) add(K_RUBBLE, randFree(c, 24));
    int nz = R.i(2, 5); for (int i = 0; i < nz; i++) add(R.f() < .15f ? K_RUNNER : K_ZOMBIE, randFree(c, 20));
    if (R.f() < .3f) add(K_BRUTE, randFree(c, 16));
  }
  void buildOutpost() {
    int sx = (int)start.x, sy = (int)start.y;
    auto S = [&](float dx, float dy) { return Vec2(start.x + dx, start.y + dy); };
    int x0 = sx - 8, y0 = sy - 6, x1 = sx + 16, y1 = sy + 18;
    for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
      bool edge = (x == x0 || x == x1 || y == y0 || y == y1); int i = y * MW + x;
      if (edge) { if (ground[i] != 3) cell[i] = 3; } else cell[i] = 0;
    }
    room(sx - 4, sy - 3, 8, 7, 4, 1, true, false);
    add(K_NOTE, S(1, -1)); ents.back().aux = 0;
    add(K_WSHOT, S(-2, -1)); add(K_AMMO9, S(1.7f, 1)); add(K_AMMO12, S(-2.1f, 1.3f));
    add(K_ARMOR, S(.5f, 1.8f)); add(K_HEALTH, S(2.f, -1.5f)); add(K_PILLS, S(-2.3f, -1.6f));
    int id = add(K_CAR, S(8, 8));
    Ent& h = ents[id]; h.tex = S_HAULER; h.aux = 0; h.hauler = true; h.hp = 400; haulerIdx = id;
    add(K_BARREL, S(11, 2)); add(K_XBARREL, S(12, 12)); add(K_BARREL, S(-5.7f, 12));
    add(K_LAMP, S(5, 5)); add(K_LAMP, S(-5, 14)); add(K_HEALTH, S(10, -3.7f));
  }
  void buildTower() {
    auto S = [&](float dx, float dy) { return Vec2(tower.x + dx, tower.y + dy); };
    room((int)tower.x - 6, (int)tower.y + 6, 8, 6, 3, 0, true, false);
    int id = add(K_NOTE, S(-3, 9)); ents[id].aux = (float)(NLORE - 1);
    add(K_RADIO, tower);
    for (int i = 0; i < 6; i++) add(K_RUBBLE, randFree(tower, 14));
    for (int i = 0; i < 3; i++) add(K_BARREL, randFree(tower, 12));
    add(K_XBARREL, randFree(tower, 10)); add(K_LAMP, S(-9, 3)); add(K_LAMP, S(6, 3));
    for (int i = 0; i < 7; i++) add(i % 3 == 0 ? K_RUNNER : K_ZOMBIE, randFree(tower, 18));
    add(K_AMMO9, S(-5, 8)); add(K_AMMO556, S(0, 8)); add(K_HEALTH, S(-4, 10)); add(K_ARMOR, S(-2, 9));
  }
  void buildHarbor() {
    for (int k = 0; k < 10; k++) {
      int bw = R.i(4, 6), bh = R.i(2, 3), bx = (int)harbor.x + R.i(-18, 18), by = (int)harbor.y + R.i(-18, 18);
      if (dist(Vec2((float)bx, (float)by), harbor) < 9) continue;
      for (int y = by; y < by + bh; y++) for (int x = bx; x < bx + bw; x++) if (in(x, y) && !cell[y * MW + x] && ground[y * MW + x] != 3) cell[y * MW + x] = 3;
    }
    add(K_SHIP, Vec2(harbor.x - 14, harbor.y + 14));
    for (int i = 0; i < 6; i++) add(K_LAMP, randFree(harbor, 16));
    for (int i = 0; i < 9; i++) add(i % 3 == 0 ? K_RUNNER : K_ZOMBIE, randFree(harbor, 20));
    add(K_BRUTE, randFree(harbor, 14));
  }
  void carve(int x, int y) {
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
      int xx = x + dx, yy = y + dy; if (xx < 2 || yy < 2 || xx >= MW - 2 || yy >= MH - 2) continue;
      ground[yy * MW + xx] = 3; cell[yy * MW + xx] = 0;
    }
  }
  void road(Vec2 a, Vec2 b) {
    int x = (int)a.x, y = (int)a.y, bx = (int)b.x, by = (int)b.y;
    while (x != bx) { carve(x, y); x += bx > x ? 1 : -1; }
    while (y != by) { carve(x, y); y += by > y ? 1 : -1; }
    carve(x, y);
  }

  void generate(uint32_t seed) {
    R = RNG(seed); cell.assign(MW * MH, 0); ground.assign(MW * MH, 0); indoor.assign(MW * MH, 0);
    ents.clear(); freeSlots.clear(); noteCtr = 0;
    for (int y = 0; y < MH; y++) for (int x = 0; x < MW; x++) {
      float n = fbm(x * .028f, y * .028f, 5, 4), m = fbm(x * .07f, y * .07f, 9, 3);
      uint8_t g = n < .42f ? 2 : (n < .56f ? 0 : 1); if (m > .68f) g = 4;
      ground[y * MW + x] = g;
      if (fbm(x * .035f, y * .035f, 11, 4) > .665f) cell[y * MW + x] = 8;
      if (x < 2 || y < 2 || x >= MW - 2 || y >= MH - 2) cell[y * MW + x] = 8;
    }
    std::vector<Vec2> sites = {start, tower, harbor}, towns;
    for (int a = 0; a < 8000 && towns.size() < 64; a++) {
      Vec2 p(R.r(40, MW - 40), R.r(40, MH - 40)); bool ok = true;
      for (auto& s : sites) if (dist(p, s) < 70) ok = false;
      for (auto& s : towns) if (dist(p, s) < 60) ok = false;
      if (ok) towns.push_back(p);
    }
    std::vector<Vec2> all = sites; all.insert(all.end(), towns.begin(), towns.end());
    for (auto& s : all) for (int y = (int)s.y - 24; y <= (int)s.y + 24; y++) for (int x = (int)s.x - 24; x <= (int)s.x + 24; x++)
      if (x >= 2 && y >= 2 && x < MW - 2 && y < MH - 2 && cell[y * MW + x] == 8 && dist(Vec2((float)x, (float)y), s) < 24) cell[y * MW + x] = 0;
    for (size_t i = 1; i < all.size(); i++) {
      size_t best = 0; float bd = 1e9f;
      for (size_t j = 0; j < i; j++) { float d = dist(all[i], all[j]); if (d < bd) { bd = d; best = j; } }
      road(all[i], all[best]);
    }
    buildOutpost(); buildTower(); buildHarbor();
    for (auto& t : towns) buildTown(t);

    // story loot: 3 fuel cans in the nearest towns, a carbine a bit further out
    std::vector<Vec2> byDist = towns;
    std::sort(byDist.begin(), byDist.end(), [&](Vec2 a, Vec2 b) { return dist(a, start) < dist(b, start); });
    for (int i = 0; i < 3 && i < (int)byDist.size(); i++) add(K_FUEL, randIndoor(byDist[i], 20));
    if (byDist.size() > 4) { add(K_WRIF, randIndoor(byDist[3], 20)); add(K_AMMO556, randIndoor(byDist[3], 20)); }
    for (int i = 0; i < 4; i++) add(K_FUEL, randIndoor(towns[R.i(0, (int)towns.size() - 1)], 20));

    // wilderness
    for (int a = 0; a < 56000; a++) {
      int x = R.i(4, MW - 5), y = R.i(4, MH - 5), i = y * MW + x;
      if (cell[i] || ground[i] == 3 || ground[i] == 5 || dist(Vec2((float)x, (float)y), start) < 14) continue;
      if (fbm(x * .05f, y * .05f, 21, 3) < .5f) continue;
      if (R.f() < .28f) add(K_TREE, Vec2(x + R.f(), y + R.f()));
    }
    for (int a = 0; a < 2800; a++) {
      int x = R.i(4, MW - 5), y = R.i(4, MH - 5), i = y * MW + x;
      if (cell[i] || ground[i] == 5 || dist(Vec2((float)x, (float)y), start) < 14) continue;
      Vec2 p(x + .5f, y + .5f); float f = R.f();
      if (f < .35f) add(K_RUBBLE, p);
      else if (f < .50f) add(R.f() < .15f ? K_XBARREL : K_BARREL, p);
      else if (f < .58f && ground[i] == 3) { int id = add(K_CAR, p); bool wr = R.f() < .7f; ents[id].wreck = wr; ents[id].tex = wr ? S_WRECK : S_SEDAN; if (wr) ents[id].aux = 0; }
      else if (f < .83f) add(R.f() < .08f ? K_RUNNER : K_ZOMBIE, p);
      else if (f < .96f) add(pickLoot() == K_FUEL ? K_AMMO9 : pickLoot(), p);
      else add(K_BRUTE, p);
    }
    for (int a = 0; a < 360; a++) { Vec2 p = randFree(Vec2(R.r(30, MW - 30), R.r(30, MH - 30)), 1); if (dist(p, start) > 14) add(pickLoot(), p); }
    // safe start: no enemies anywhere near the outpost
    for (int i = 0; i < (int)ents.size(); i++) if (!ents[i].dead && isEnemy(ents[i].k) && dist(ents[i].pos, start) < 100) kill(i);
  }
};

// ---------- DDA raycast (shared by renderer, hitscan and spawner) ----------
struct RayHit { float dist = 0, wx = 0; int cx = 0, cy = 0, side = 0, cv = 0; bool hit = false; };
inline RayHit castRay(const World& w, Vec2 o, Vec2 rd, float maxd) {
  RayHit h; int mx = (int)std::floor(o.x), my = (int)std::floor(o.y);
  float ddx = rd.x == 0 ? 1e30f : std::fabs(1.f / rd.x), ddy = rd.y == 0 ? 1e30f : std::fabs(1.f / rd.y);
  int sx, sy; float sdx, sdy;
  if (rd.x < 0) { sx = -1; sdx = (o.x - mx) * ddx; } else { sx = 1; sdx = (mx + 1.f - o.x) * ddx; }
  if (rd.y < 0) { sy = -1; sdy = (o.y - my) * ddy; } else { sy = 1; sdy = (my + 1.f - o.y) * ddy; }
  int side = 0; float t = 0;
  for (int n = 0; n < 400; n++) {
    if (sdx < sdy) { t = sdx; sdx += ddx; mx += sx; side = 0; } else { t = sdy; sdy += ddy; my += sy; side = 1; }
    if (t > maxd) break;
    int c = w.cellAt(mx, my);
    if (c != 0 && c != 6) {
      h.hit = true; h.dist = t; h.cx = mx; h.cy = my; h.side = side; h.cv = c;
      float wx = side == 0 ? o.y + rd.y * t : o.x + rd.x * t; wx -= std::floor(wx);
      if ((side == 0 && rd.x > 0) || (side == 1 && rd.y < 0)) wx = 1.f - wx;
      h.wx = wx; return h;
    }
  }
  h.dist = maxd; return h;
}

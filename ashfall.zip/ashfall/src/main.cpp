#include "render.h"

int main(int argc, char** argv) {
  SDL_SetMainReady();
  uint32_t seed = argc > 1 ? (uint32_t)std::atoi(argv[1]) : 1337u;
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
    std::fprintf(stderr, "SDL init failed: %s\n", SDL_GetError());
    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ASHFALL", SDL_GetError(), nullptr);
    return 1;
  }
  SDL_Window* win = SDL_CreateWindow("ASHFALL v0.1", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 720, SDL_WINDOW_RESIZABLE);
  SDL_Renderer* ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
  if (!ren) ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_SOFTWARE);
  SDL_RenderSetLogicalSize(ren, SW, SH);
  SDL_Texture* tex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, SW, SH);

  // show a loading screen while the world generates
  std::memset(FB, 0, sizeof(FB)); drawCentered(SH / 2 - 8, "GENERATING WORLD...", 2, rgb(200, 60, 50));
  SDL_UpdateTexture(tex, nullptr, FB, SW * 4); SDL_RenderClear(ren); SDL_RenderCopy(ren, tex, nullptr, nullptr); SDL_RenderPresent(ren);
  Game* g = new Game();
  std::printf("Generating world (seed %u)...\n", seed);
  g->init(seed);

  bool running = true, fullscreen = false; Uint64 last = SDL_GetPerformanceCounter();
  while (running) {
    SDL_Event ev;
    while (SDL_PollEvent(&ev)) {
      switch (ev.type) {
        case SDL_QUIT: running = false; break;
        case SDL_MOUSEMOTION: if (g->st == ST_PLAY && !g->showObj && !g->showInv) { g->mouseDX += ev.motion.xrel; g->mouseDY += ev.motion.yrel; } break;
        case SDL_MOUSEBUTTONDOWN: if (ev.button.button == SDL_BUTTON_LEFT) { g->fireHeld = true; g->fireLatch = true; } break;
        case SDL_MOUSEBUTTONUP: if (ev.button.button == SDL_BUTTON_LEFT) g->fireHeld = false; break;
        case SDL_KEYDOWN: {
          if (ev.key.repeat) break;
          SDL_Scancode k = ev.key.keysym.scancode;
          if (k == SDL_SCANCODE_F11) { fullscreen = !fullscreen; SDL_SetWindowFullscreen(win, fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0); }
          else if (k == SDL_SCANCODE_ESCAPE) running = false;
          else if (k == SDL_SCANCODE_RETURN && g->st == ST_TITLE) g->st = ST_PLAY;
          else if (k == SDL_SCANCODE_R && g->st != ST_PLAY && g->st != ST_TITLE) { g->reset(); g->st = ST_PLAY; }
          else if (g->st == ST_PLAY) {
            if (k == SDL_SCANCODE_TAB) { g->showObj = !g->showObj; g->showInv = false; }
            else if (k == SDL_SCANCODE_I) { g->showInv = !g->showInv; g->showObj = false; }
            else if (k == SDL_SCANCODE_H) g->useMed();
            else if (k == SDL_SCANCODE_G) g->usePills();
            else if (!g->showObj && !g->showInv) {
              if (k == SDL_SCANCODE_M) g->showMap = !g->showMap;
              else if (k == SDL_SCANCODE_E) g->interact();
              else if (k == SDL_SCANCODE_R) g->reload();
              else if (k == SDL_SCANCODE_F) g->flashlight = !g->flashlight;
              else if (k == SDL_SCANCODE_SPACE) g->jumpReq = true;
              else if (k >= SDL_SCANCODE_1 && k <= SDL_SCANCODE_4) g->selectWeapon(k - SDL_SCANCODE_1);
            }
          }
          break; }
      }
    }
    SDL_SetRelativeMouseMode((g->st == ST_PLAY && !g->showObj && !g->showInv) ? SDL_TRUE : SDL_FALSE);
    Uint64 now = SDL_GetPerformanceCounter();
    float dt = (float)((now - last) / (double)SDL_GetPerformanceFrequency()); last = now;
    if (dt > .05f) dt = .05f;
    g->update(dt);
    renderScene(*g);
    SDL_UpdateTexture(tex, nullptr, FB, SW * 4);
    SDL_RenderClear(ren); SDL_RenderCopy(ren, tex, nullptr, nullptr); SDL_RenderPresent(ren);
  }
  SDL_Quit();
  return 0;
}

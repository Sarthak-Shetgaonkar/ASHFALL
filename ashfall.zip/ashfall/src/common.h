#pragma once
#define SDL_MAIN_HANDLED
#if __has_include(<SDL2/SDL.h>)
#include <SDL2/SDL.h>
#else
#include <SDL.h>
#endif
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

constexpr int SW = 640, SH = 360;   // internal render resolution (upscaled by SDL)
constexpr int MW = 1024, MH = 1024;   // world size in cells
constexpr float PI = 3.14159265f;
constexpr float PLANE = 0.82f;                 // camera plane half-width (FOV)
constexpr float FOCAL = (SW * 0.5f) / PLANE;   // pixels per world unit at depth 1

inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
inline int c255(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

struct Vec2 {
  float x = 0, y = 0;
  Vec2() {}
  Vec2(float x_, float y_) : x(x_), y(y_) {}
  Vec2 operator+(Vec2 o) const { return {x + o.x, y + o.y}; }
  Vec2 operator-(Vec2 o) const { return {x - o.x, y - o.y}; }
  Vec2 operator*(float s) const { return {x * s, y * s}; }
  float len() const { return std::sqrt(x * x + y * y); }
};
inline float dot(Vec2 a, Vec2 b) { return a.x * b.x + a.y * b.y; }
inline float cross2(Vec2 a, Vec2 b) { return a.x * b.y - a.y * b.x; }
inline float dist(Vec2 a, Vec2 b) { return (a - b).len(); }

inline uint32_t rgb(int r, int g, int b) { return 0xFF000000u | ((uint32_t)c255(r) << 16) | ((uint32_t)c255(g) << 8) | (uint32_t)c255(b); }
// alpha 0xFE marks an emissive texel (ignores darkness, only fogged)
inline uint32_t glowc(int r, int g, int b) { return 0xFE000000u | ((uint32_t)c255(r) << 16) | ((uint32_t)c255(g) << 8) | (uint32_t)c255(b); }

struct RNG {
  uint32_t s;
  explicit RNG(uint32_t seed = 1) : s(seed ? seed : 1) {}
  uint32_t u() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
  float f() { return (u() & 0xFFFFFF) / 16777216.f; }
  float r(float a, float b) { return a + (b - a) * f(); }
  int i(int a, int b) { return a + (int)(u() % (uint32_t)(b - a + 1)); }
};

// ---------- noise ----------
inline uint32_t hash32(uint32_t x) { x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16; return x; }
inline float hrand(int x, int y, int s = 0) {
  return (hash32((uint32_t)x * 73856093u ^ (uint32_t)y * 19349663u ^ (uint32_t)s * 83492791u) & 0xFFFFFF) / 16777216.f;
}
inline float vnoise(float x, float y, int s = 0, int wrap = 0) {
  int xi = (int)std::floor(x), yi = (int)std::floor(y);
  float fx = x - xi, fy = y - yi;
  fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
  auto H = [&](int a, int b) { if (wrap) a = ((a % wrap) + wrap) % wrap; return hrand(a, b, s); };
  return lerpf(lerpf(H(xi, yi), H(xi + 1, yi), fx), lerpf(H(xi, yi + 1), H(xi + 1, yi + 1), fx), fy);
}
inline float fbm(float x, float y, int s = 0, int oct = 4) {
  float a = 0.5f, sum = 0, norm = 0;
  for (int i = 0; i < oct; i++) { sum += a * vnoise(x, y, s + i * 13); norm += a; x *= 2.03f; y *= 2.03f; a *= 0.5f; }
  return sum / norm;
}

// ---------- software texture ----------
struct Tex {
  int w = 0, h = 0;
  std::vector<uint32_t> px;
  Tex() {}
  Tex(int w_, int h_) : w(w_), h(h_), px((size_t)w_ * h_, 0) {}
  uint32_t get(int x, int y) const { return px[(size_t)y * w + x]; }
  void set(int x, int y, uint32_t c) { if ((unsigned)x < (unsigned)w && (unsigned)y < (unsigned)h) px[(size_t)y * w + x] = c; }
  void rect(int x0, int y0, int x1, int y1, uint32_t c) { for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) set(x, y, c); }
  void ellipse(float cx, float cy, float rx, float ry, uint32_t c) {
    for (int y = (int)std::floor(cy - ry); y <= (int)std::ceil(cy + ry); y++)
      for (int x = (int)std::floor(cx - rx); x <= (int)std::ceil(cx + rx); x++) {
        float dx = (x + .5f - cx) / rx, dy = (y + .5f - cy) / ry;
        if (dx * dx + dy * dy <= 1.f) set(x, y, c);
      }
  }
  void line(float x0, float y0, float x1, float y1, float th, uint32_t c) {
    int n = (int)(std::max(std::fabs(x1 - x0), std::fabs(y1 - y0)) * 2) + 1;
    for (int i = 0; i <= n; i++) { float t = (float)i / n; ellipse(lerpf(x0, x1, t), lerpf(y0, y1, t), th / 2, th / 2, c); }
  }
  void trap(int y0, int y1, float cx0, float w0, float cx1, float w1, uint32_t c) {
    for (int y = y0; y < y1; y++) {
      float t = (float)(y - y0) / (float)std::max(1, y1 - y0 - 1);
      float cx = lerpf(cx0, cx1, t), ww = lerpf(w0, w1, t);
      rect((int)(cx - ww / 2), y, (int)(cx + ww / 2), y + 1, c);
    }
  }
  void grunge(float amt, int seed) {
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
      uint32_t c = px[(size_t)y * w + x];
      if ((c >> 24) != 0xFF) continue;
      float k = 1.f - amt * (0.6f * hrand(x, y, seed) + 0.8f * fbm(x * 0.15f, y * 0.15f, seed, 3));
      px[(size_t)y * w + x] = rgb((int)(((c >> 16) & 255) * k), (int)(((c >> 8) & 255) * k), (int)((c & 255) * k));
    }
  }
};

// ---------- framebuffer + text ----------
inline uint32_t FB[SW * SH];
inline float ZB[SW];

inline void blendPx(int x, int y, uint32_t c, float a) {
  if ((unsigned)x >= (unsigned)SW || (unsigned)y >= (unsigned)SH) return;
  uint32_t& d = FB[y * SW + x];
  int dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
  int sr = (c >> 16) & 255, sg = (c >> 8) & 255, sb = c & 255;
  d = rgb((int)(dr + (sr - dr) * a), (int)(dg + (sg - dg) * a), (int)(db + (sb - db) * a));
}
inline void fillRect(int x, int y, int w, int h, uint32_t c, float a = 1.f) {
  int x0 = std::max(0, x), y0 = std::max(0, y), x1 = std::min(SW, x + w), y1 = std::min(SH, y + h);
  for (int yy = y0; yy < y1; yy++) for (int xx = x0; xx < x1; xx++) {
    if (a >= 0.999f) FB[yy * SW + xx] = c; else blendPx(xx, yy, c, a);
  }
}

// 5x7 font, ASCII 32..90 (lowercase is drawn as uppercase)
inline const uint8_t FONT[59][5] = {
  {0x00,0x00,0x00,0x00,0x00},{0x00,0x00,0x5F,0x00,0x00},{0x00,0x07,0x00,0x07,0x00},{0x14,0x7F,0x14,0x7F,0x14},
  {0x24,0x2A,0x7F,0x2A,0x12},{0x23,0x13,0x08,0x64,0x62},{0x36,0x49,0x56,0x20,0x50},{0x00,0x08,0x07,0x03,0x00},
  {0x00,0x1C,0x22,0x41,0x00},{0x00,0x41,0x22,0x1C,0x00},{0x2A,0x1C,0x7F,0x1C,0x2A},{0x08,0x08,0x3E,0x08,0x08},
  {0x00,0x80,0x70,0x30,0x00},{0x08,0x08,0x08,0x08,0x08},{0x00,0x00,0x60,0x60,0x00},{0x20,0x10,0x08,0x04,0x02},
  {0x3E,0x51,0x49,0x45,0x3E},{0x00,0x42,0x7F,0x40,0x00},{0x72,0x49,0x49,0x49,0x46},{0x21,0x41,0x49,0x4D,0x33},
  {0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x31},{0x41,0x21,0x11,0x09,0x07},
  {0x36,0x49,0x49,0x49,0x36},{0x46,0x49,0x49,0x29,0x1E},{0x00,0x00,0x14,0x00,0x00},{0x00,0x40,0x34,0x00,0x00},
  {0x00,0x08,0x14,0x22,0x41},{0x14,0x14,0x14,0x14,0x14},{0x00,0x41,0x22,0x14,0x08},{0x02,0x01,0x59,0x09,0x06},
  {0x3E,0x41,0x5D,0x59,0x4E},{0x7C,0x12,0x11,0x12,0x7C},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},
  {0x7F,0x41,0x41,0x41,0x3E},{0x7F,0x49,0x49,0x49,0x41},{0x7F,0x09,0x09,0x09,0x01},{0x3E,0x41,0x41,0x51,0x73},
  {0x7F,0x08,0x08,0x08,0x7F},{0x00,0x41,0x7F,0x41,0x00},{0x20,0x40,0x41,0x3F,0x01},{0x7F,0x08,0x14,0x22,0x41},
  {0x7F,0x40,0x40,0x40,0x40},{0x7F,0x02,0x1C,0x02,0x7F},{0x7F,0x04,0x08,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},
  {0x7F,0x09,0x09,0x09,0x06},{0x3E,0x41,0x51,0x21,0x5E},{0x7F,0x09,0x19,0x29,0x46},{0x26,0x49,0x49,0x49,0x32},
  {0x03,0x01,0x7F,0x01,0x03},{0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},
  {0x63,0x14,0x08,0x14,0x63},{0x03,0x04,0x78,0x04,0x03},{0x61,0x59,0x49,0x4D,0x43}};

inline int textW(const std::string& s, int sc) { return (int)s.size() * 6 * sc; }
inline void drawChars(int x, int y, const std::string& s, int sc, uint32_t col) {
  for (char ch : s) {
    int i = (unsigned char)ch;
    if (i >= 'a' && i <= 'z') i -= 32;
    if (i >= 32 && i <= 90) {
      const uint8_t* g = FONT[i - 32];
      for (int cx = 0; cx < 5; cx++) for (int cy = 0; cy < 8; cy++) if ((g[cx] >> cy) & 1) fillRect(x + cx * sc, y + cy * sc, sc, sc, col);
    }
    x += 6 * sc;
  }
}
inline void drawText(int x, int y, const std::string& s, int sc, uint32_t col, bool shadow = true) {
  if (shadow) drawChars(x + sc, y + sc, s, sc, rgb(0, 0, 0));
  drawChars(x, y, s, sc, col);
}
inline void drawCentered(int y, const std::string& s, int sc, uint32_t col) { drawText((SW - textW(s, sc)) / 2, y, s, sc, col); }
inline std::vector<std::string> wrapText(const std::string& s, size_t maxc) {
  std::vector<std::string> out; std::string line, word;
  auto flush = [&]() { if (!word.empty()) { if (line.size() + word.size() + 1 > maxc && !line.empty()) { out.push_back(line); line.clear(); } if (!line.empty()) line += ' '; line += word; word.clear(); } };
  for (char c : s) { if (c == ' ') flush(); else word += c; }
  flush(); if (!line.empty()) out.push_back(line);
  return out;
}

#pragma once
#include "common.h"

// Fully synthesized audio: gunshots, groans, wind, a low drone, and an engine loop.
struct Audio {
  enum { SHOT9, SHOTSG, SHOTRF, RELOAD, HIT, GROAN1, GROAN2, PICKUP, HURT, DOOR, BOOM, SWING, BEAT, NSND };
  struct Voice { int id = -1; size_t pos = 0; float vol = 0; };
  std::vector<int16_t> snd[NSND];
  Voice voices[16];
  SDL_AudioDeviceID dev = 0;
  float engine = 0, engFreq = 40;
  uint32_t rs = 777;
  float wlp = 0, wph = 0, dph1 = 0, dph2 = 0, eph = 0;

  float rnd() { rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; return (rs & 0xFFFF) / 32768.f - 1.f; }
  static int16_t clip(float v) { return (int16_t)(v > 32000 ? 32000 : (v < -32000 ? -32000 : v)); }

  std::vector<int16_t> noise(float dur, float decay, float k, float vol) {
    std::vector<int16_t> d((size_t)(dur * 44100)); float lp = 0;
    for (size_t i = 0; i < d.size(); i++) { float t = i / 44100.f; lp += (rnd() - lp) * k; d[i] = clip(lp * std::exp(-t * decay) * vol * 30000); }
    return d;
  }
  std::vector<int16_t> tone(float dur, float f0, float f1, float decay, float vol, bool saw, float nz = 0) {
    std::vector<int16_t> d((size_t)(dur * 44100)); float ph = 0;
    for (size_t i = 0; i < d.size(); i++) {
      float t = i / 44100.f, f = lerpf(f0, f1, t / dur) * (1.f + 0.03f * std::sin(t * 31));
      ph += f / 44100.f; ph -= std::floor(ph);
      float s = saw ? (ph * 2 - 1) : std::sin(2 * PI * ph);
      d[i] = clip((s + nz * rnd()) * std::exp(-t * decay) * vol * 30000);
    }
    return d;
  }
  static void add(std::vector<int16_t>& a, const std::vector<int16_t>& b, size_t off = 0, float g = 1) {
    if (a.size() < off + b.size()) a.resize(off + b.size(), 0);
    for (size_t i = 0; i < b.size(); i++) a[off + i] = clip((float)a[off + i] + b[i] * g);
  }

  void init() {
    snd[SHOT9] = noise(0.22f, 20, 0.55f, 0.9f); add(snd[SHOT9], tone(0.12f, 150, 50, 25, 0.7f, false));
    snd[SHOTSG] = noise(0.5f, 9, 0.35f, 1.0f); add(snd[SHOTSG], tone(0.3f, 90, 30, 10, 0.9f, false));
    snd[SHOTRF] = noise(0.3f, 14, 0.5f, 0.8f); add(snd[SHOTRF], tone(0.15f, 200, 60, 20, 0.6f, false));
    snd[RELOAD] = noise(0.04f, 80, 1.f, 0.5f); add(snd[RELOAD], noise(0.05f, 70, 1.f, 0.5f), 7000);
    snd[HIT] = tone(0.15f, 160, 60, 18, 0.8f, false); add(snd[HIT], noise(0.1f, 30, 0.3f, 0.5f));
    snd[GROAN1] = tone(0.9f, 75, 48, 2.2f, 0.5f, true, 0.12f);
    snd[GROAN2] = tone(1.1f, 110, 60, 2.f, 0.45f, true, 0.15f);
    snd[PICKUP] = tone(0.18f, 700, 1100, 8, 0.4f, false);
    snd[HURT] = tone(0.25f, 90, 40, 10, 0.9f, false); add(snd[HURT], noise(0.2f, 15, 0.2f, 0.6f));
    snd[DOOR] = tone(0.7f, 95, 70, 2.5f, 0.5f, true, 0.2f);
    snd[BOOM] = noise(1.4f, 3, 0.12f, 1.0f); add(snd[BOOM], tone(0.8f, 60, 25, 3, 1.f, false));
    snd[SWING] = noise(0.18f, 12, 0.15f, 0.5f);
    snd[BEAT] = tone(0.12f, 55, 38, 16, 0.9f, false); add(snd[BEAT], tone(0.12f, 50, 35, 16, 0.7f, false), 8000);
    SDL_AudioSpec want; SDL_zero(want);
    want.freq = 44100; want.format = AUDIO_S16SYS; want.channels = 1; want.samples = 1024; want.callback = cb; want.userdata = this;
    dev = SDL_OpenAudioDevice(nullptr, 0, &want, nullptr, 0);
    if (dev) SDL_PauseAudioDevice(dev, 0);
  }
  void play(int id, float vol = 1.f) {
    if (!dev || vol <= 0.01f) return;
    SDL_LockAudioDevice(dev);
    int slot = 0; for (int i = 0; i < 16; i++) if (voices[i].id < 0) { slot = i; break; }
    voices[slot].id = id; voices[slot].pos = 0; voices[slot].vol = vol;
    SDL_UnlockAudioDevice(dev);
  }
  void setEngine(float v, float f) { if (!dev) return; SDL_LockAudioDevice(dev); engine = v; engFreq = f; SDL_UnlockAudioDevice(dev); }
  static void cb(void* ud, Uint8* st, int len) { ((Audio*)ud)->mix((int16_t*)st, len / 2); }
  void mix(int16_t* out, int n) {
    for (int i = 0; i < n; i++) {
      float s = 0;
      for (auto& v : voices) if (v.id >= 0) {
        auto& d = snd[v.id]; s += d[v.pos] / 32768.f * v.vol;
        if (++v.pos >= d.size()) v.id = -1;
      }
      wlp += (rnd() - wlp) * 0.02f; wph += 2 * PI * 0.11f / 44100.f; if (wph > 2 * PI) wph -= 2 * PI;
      s += wlp * (1.3f + 0.9f * std::sin(wph));
      dph1 += 2 * PI * 52.f / 44100.f; if (dph1 > 2 * PI) dph1 -= 2 * PI;
      dph2 += 2 * PI * 52.6f / 44100.f; if (dph2 > 2 * PI) dph2 -= 2 * PI;
      s += 0.03f * (std::sin(dph1) + std::sin(dph2));
      if (engine > 0.001f) { eph += engFreq / 44100.f; eph -= std::floor(eph); s += ((eph * 2 - 1) * 0.45f + rnd() * 0.08f) * engine * 0.4f; }
      s = s > 1 ? 1 : (s < -1 ? -1 : s);
      out[i] = (int16_t)(s * 28000);
    }
  }
};
